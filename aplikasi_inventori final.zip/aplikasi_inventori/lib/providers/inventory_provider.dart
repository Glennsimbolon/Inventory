import 'package:flutter/material.dart';

import '../database/database_helper.dart';
import '../models/barang_model.dart';
import '../models/transaksi_model.dart';

class InventoryProvider extends ChangeNotifier {

  final DatabaseHelper _db =
      DatabaseHelper();

  List<Barang> barangList=[];

  List<Transaksi>
      transaksiList=[];

  bool isLoading=false;

  Future<void> loadBarang() async {

    isLoading=true;

    notifyListeners();

    try{

      barangList=
      await _db.getAllBarang();

    }catch(e){

      debugPrint(
        "Load barang error: $e"
      );

    }

    isLoading=false;

    notifyListeners();

  }

  Future<void> loadTransaksi() async {

    try{

      transaksiList=
      await _db.getAllTransaksi();

    }catch(e){

      debugPrint(
          "Load transaksi error: $e"
      );

    }

    notifyListeners();

  }

  Future<void> tambahBarangMasuk({

    required Barang barang,
    required int jumlah,
    String? ket,
    String? noRef,

  }) async {

    try{

      final stokBaru =
          barang.stok + jumlah;

      // update stok lokal
      await _db.updateStokBarang(
        barang.id!,
        stokBaru,
      );

      // simpan transaksi
      await _db.insertTransaksi(

        Transaksi(

          barangId:
          barang.id!,

          barangNama:
          barang.nama,

          barangIkon:
          barang.ikon,

          tipe:
          TipeTransaksi.masuk,

          jumlah:
          jumlah,

          stokSebelum:
          barang.stok,

          stokSesudah:
          stokBaru,

          keterangan:
          ket,

          nomorReferensi:
          noRef,

        ),

      );

      // reload data
      await loadBarang();

      await loadTransaksi();

    }catch(e){

      debugPrint(
          "Tambah barang gagal: $e"
      );

    }

    notifyListeners();

  }

}
// lib/database/database_helper.dart
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'dart:io';
import 'package:supabase_flutter/supabase_flutter.dart' hide User;
import '../models/user_model.dart';
import '../models/supplier_model.dart';
import '../models/barang_model.dart';
import '../models/transaksi_model.dart';

class DatabaseHelper {
  static final DatabaseHelper _instance = DatabaseHelper._internal();
  factory DatabaseHelper() => _instance;
  DatabaseHelper._internal();

  static Database? _database;
  static const int    _dbVersion = 2;
  static const String _dbName    = 'inventaris_ta.db';

  Future<Database> get database async {
    _database ??= await _initDatabase();
    return _database!;
  }

  // ==================== SUPABASE HELPER ====================
  SupabaseClient? _getSupabase() {
    try {
      return Supabase.instance.client;
    } catch (_) {
      return null;
    }
  }

  /// Kirim data ke Supabase (insert/update)
  Future<void> _syncToSupabase(String table, Map<String, dynamic> data, {int? id}) async {
    final supabase = _getSupabase();
    if (supabase == null) return;
    try {
      if (id != null && id > 0) {
        await supabase.from(table).upsert(data);
      } else {
        await supabase.from(table).insert(data);
      }
    } catch (e) {
      print("❌ Sync error ke Supabase ($table): $e");
    }
  }

  /// Hapus data dari Supabase
  Future<void> _deleteFromSupabase(String table, int id) async {
    final supabase = _getSupabase();
    if (supabase == null) return;
    try {
      await supabase.from(table).delete().eq('id', id);
    } catch (e) {
      print("❌ Delete error dari Supabase ($table): $e");
    }
  }

  // ==================== PULL DATA DARI SUPABASE KE SQLITE ====================
  /// Tarik semua supplier dari Supabase ke SQLite (update/insert)
  Future<void> pullSuppliers() async {
    final supabase = _getSupabase();
    if (supabase == null) return;
    try {
      final List<dynamic> raw = await supabase.from('suppliers').select();
      final db = await database;
      for (var item in raw) {
        final Map<String, dynamic> row = Map<String, dynamic>.from(item);
        final id = row['id'];
        final existing = await db.query('suppliers', where: 'id = ?', whereArgs: [id]);
        if (existing.isNotEmpty) {
          await db.update('suppliers', row, where: 'id = ?', whereArgs: [id]);
        } else {
          await db.insert('suppliers', row);
        }
      }
      print('✅ Pull suppliers sukses, ${raw.length} data');
    } catch (e) {
      print('❌ Pull suppliers gagal: $e');
    }
  }

  /// Tarik semua barang dari Supabase ke SQLite
  Future<void> pullBarang() async {
    final supabase = _getSupabase();
    if (supabase == null) return;
    try {
      final List<dynamic> raw = await supabase.from('barang').select();
      final db = await database;
      for (var item in raw) {
        final Map<String, dynamic> row = Map<String, dynamic>.from(item);
        final id = row['id'];
        final existing = await db.query('barang', where: 'id = ?', whereArgs: [id]);
        if (existing.isNotEmpty) {
          await db.update('barang', row, where: 'id = ?', whereArgs: [id]);
        } else {
          await db.insert('barang', row);
        }
      }
      print('✅ Pull barang sukses, ${raw.length} data');
    } catch (e) {
      print('❌ Pull barang gagal: $e');
    }
  }

  /// Tarik semua transaksi dari Supabase ke SQLite
  Future<void> pullTransaksi() async {
    final supabase = _getSupabase();
    if (supabase == null) return;
    try {
      final List<dynamic> raw = await supabase.from('transaksi').select();
      final db = await database;
      for (var item in raw) {
        final Map<String, dynamic> row = Map<String, dynamic>.from(item);
        final id = row['id'];
        final existing = await db.query('transaksi', where: 'id = ?', whereArgs: [id]);
        if (existing.isNotEmpty) {
          await db.update('transaksi', row, where: 'id = ?', whereArgs: [id]);
        } else {
          await db.insert('transaksi', row);
        }
      }
      print('✅ Pull transaksi sukses, ${raw.length} data');
    } catch (e) {
      print('❌ Pull transaksi gagal: $e');
    }
  }

  /// Tarik semua data (supplier, barang, transaksi) sekaligus
  Future<void> pullAllData() async {
    await pullSuppliers();
    await pullBarang();
    await pullTransaksi();
    print('✅ Sinkronasi pull lengkap selesai');
  }

  // ==================== INISIALISASI & DDL ====================
  Future<String> getDatabasePath() async {
    final dbPath = await getDatabasesPath();
    return p.join(dbPath, _dbName);
  }

  Future<Database> _initDatabase() async {
    final path = await getDatabasePath();
    return await openDatabase(
      path,
      version: _dbVersion,
      onConfigure: (db) async {
        await db.execute('PRAGMA foreign_keys = ON');
        await db.rawQuery('PRAGMA journal_mode=WAL');
      },
      onCreate: _createTables,
      onUpgrade: _onUpgrade,
    );
  }

  Future<void> _onUpgrade(Database db, int oldV, int newV) async {
    if (oldV < 2) {
      await _createUsersTable(db);
      await _seedUsers(db);
    }
  }

  Future<void> _createTables(Database db, int version) async {
    await _createUsersTable(db);
    await _createSupplierTable(db);
    await _createBarangTable(db);
    await _createTransaksiTable(db);
    await _seedAll(db);
  }

  Future<void> _createUsersTable(Database db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS users (
        id            INTEGER PRIMARY KEY AUTOINCREMENT,
        username      TEXT    NOT NULL UNIQUE,
        password_hash TEXT    NOT NULL,
        nama_lengkap  TEXT    NOT NULL,
        role          TEXT    NOT NULL DEFAULT 'operator',
        email         TEXT,
        foto_profil   TEXT,
        is_active     INTEGER NOT NULL DEFAULT 1,
        last_login    TEXT,
        created_at    TEXT    NOT NULL
      )
    ''');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_users_username ON users(username)');
  }

  Future<void> _createSupplierTable(Database db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS suppliers (
        id         INTEGER PRIMARY KEY AUTOINCREMENT,
        nama       TEXT NOT NULL,
        kontak     TEXT NOT NULL,
        telepon    TEXT NOT NULL,
        email      TEXT DEFAULT '',
        kota       TEXT DEFAULT '',
        alamat     TEXT DEFAULT '',
        status     TEXT DEFAULT 'aktif',
        created_at TEXT NOT NULL
      )
    ''');
  }

  Future<void> _createBarangTable(Database db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS barang (
        id             INTEGER PRIMARY KEY AUTOINCREMENT,
        nama           TEXT NOT NULL,
        jenis          TEXT NOT NULL,
        satuan         TEXT DEFAULT 'pcs',
        stok           INTEGER DEFAULT 0,
        stok_minimum   INTEGER DEFAULT 5,
        foto_path      TEXT,
        ikon           TEXT DEFAULT '📦',
        supplier_id    INTEGER,
        supplier_nama  TEXT,
        keterangan     TEXT DEFAULT '',
        created_at     TEXT NOT NULL,
        updated_at     TEXT NOT NULL,
        FOREIGN KEY (supplier_id) REFERENCES suppliers(id) ON DELETE SET NULL
      )
    ''');
  }

  Future<void> _createTransaksiTable(Database db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS transaksi (
        id               INTEGER PRIMARY KEY AUTOINCREMENT,
        barang_id        INTEGER NOT NULL,
        barang_nama      TEXT NOT NULL,
        barang_ikon      TEXT DEFAULT '📦',
        tipe             TEXT NOT NULL,
        jumlah           INTEGER NOT NULL,
        stok_sebelum     INTEGER NOT NULL,
        stok_sesudah     INTEGER NOT NULL,
        keterangan       TEXT,
        nomor_referensi  TEXT,
        tanggal          TEXT NOT NULL,
        created_at       TEXT NOT NULL,
        FOREIGN KEY (barang_id) REFERENCES barang(id) ON DELETE CASCADE
      )
    ''');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_transaksi_barang ON transaksi(barang_id)');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_transaksi_tipe ON transaksi(tipe)');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_transaksi_tanggal ON transaksi(tanggal)');
  }

  // SEEDER (data awal)
  Future<void> _seedAll(Database db) async {
    await _seedUsers(db);
    await _seedSuppliers(db);
    await _seedBarang(db);
    await _seedTransaksi(db);
  }

  Future<void> _seedUsers(Database db) async {
    final now = DateTime.now().toIso8601String();
    final users = [
      {'username':'admin','password_hash':User.hashPassword('admin123'),'nama_lengkap':'Administrator','role':'admin','email':'admin@inventaris.com','is_active':1,'created_at':now},
      {'username':'operator','password_hash':User.hashPassword('operator123'),'nama_lengkap':'Operator Gudang','role':'operator','email':'operator@inventaris.com','is_active':1,'created_at':now},
      {'username':'viewer','password_hash':User.hashPassword('viewer123'),'nama_lengkap':'Viewer Laporan','role':'viewer','email':'viewer@inventaris.com','is_active':1,'created_at':now},
    ];
    for (final u in users) {
      await db.insert('users', u, conflictAlgorithm: ConflictAlgorithm.ignore);
    }
  }

  Future<void> _seedSuppliers(Database db) async {
    final now = DateTime.now().toIso8601String();
    final list = [
      {'nama':'PT Maju Jaya Elektronik','kontak':'Budi Santoso','telepon':'0812-3456-7890','email':'budi@majujaya.com','kota':'Jakarta','alamat':'Jl. Sudirman No.12','status':'aktif','created_at':now},
      {'nama':'CV Berkah Abadi Mandiri','kontak':'Siti Rahma','telepon':'0821-9876-5432','email':'siti@berkah.co.id','kota':'Surabaya','alamat':'Jl. Pemuda No.45','status':'aktif','created_at':now},
      {'nama':'Toko Sejahtera Jaya','kontak':'Ahmad Fauzi','telepon':'0813-1122-3344','email':'ahmad@sejahtera.com','kota':'Bandung','alamat':'Jl. Braga No.8','status':'nonaktif','created_at':now},
      {'nama':'UD Karya Mandiri Nusantara','kontak':'Dewi Lestari','telepon':'0857-6677-8899','email':'dewi@karyamandiri.id','kota':'Medan','alamat':'Jl. Gatot Subroto No.22','status':'aktif','created_at':now},
    ];
    for (final s in list) {
      await db.insert('suppliers', s, conflictAlgorithm: ConflictAlgorithm.ignore);
    }
  }

  Future<void> _seedBarang(Database db) async {
    final now = DateTime.now().toIso8601String();
    final list = [
      {'nama':'Laptop Dell Inspiron','jenis':'Elektronik','satuan':'unit','stok':15,'stok_minimum':3,'ikon':'💻','supplier_id':1,'supplier_nama':'PT Maju Jaya Elektronik','keterangan':'Laptop operasional kantor','created_at':now,'updated_at':now},
      {'nama':'Mouse Wireless Logitech','jenis':'Elektronik','satuan':'unit','stok':42,'stok_minimum':10,'ikon':'🖱️','supplier_id':1,'supplier_nama':'PT Maju Jaya Elektronik','keterangan':'Mouse wireless bluetooth','created_at':now,'updated_at':now},
      {'nama':'Kertas HVS A4 80gr','jenis':'Alat Tulis','satuan':'rim','stok':200,'stok_minimum':20,'ikon':'📄','supplier_id':2,'supplier_nama':'CV Berkah Abadi Mandiri','keterangan':'Untuk cetak dokumen','created_at':now,'updated_at':now},
      {'nama':'Pulpen Pilot G-2','jenis':'Alat Tulis','satuan':'lusin','stok':87,'stok_minimum':10,'ikon':'✏️','supplier_id':2,'supplier_nama':'CV Berkah Abadi Mandiri','keterangan':'Pulpen gel hitam','created_at':now,'updated_at':now},
      {'nama':'Kursi Kantor Ergonomis','jenis':'Furnitur','satuan':'unit','stok':8,'stok_minimum':2,'ikon':'🪑','supplier_id':4,'supplier_nama':'UD Karya Mandiri Nusantara','keterangan':'Kursi dengan sandaran','created_at':now,'updated_at':now},
      {'nama':'Air Mineral 600ml','jenis':'Konsumsi','satuan':'dus','stok':120,'stok_minimum':15,'ikon':'💧','supplier_id':4,'supplier_nama':'UD Karya Mandiri Nusantara','keterangan':'Air mineral isi 24','created_at':now,'updated_at':now},
      {'nama':'Teh Celup Sosro','jenis':'Konsumsi','satuan':'kotak','stok':3,'stok_minimum':5,'ikon':'🍵','supplier_id':4,'supplier_nama':'UD Karya Mandiri Nusantara','keterangan':'Teh celup 25 sachet','created_at':now,'updated_at':now},
    ];
    for (final b in list) {
      await db.insert('barang', b, conflictAlgorithm: ConflictAlgorithm.ignore);
    }
  }

  Future<void> _seedTransaksi(Database db) async {
    final now = DateTime.now().toIso8601String();
    final list = [
      {'barang_id':1,'barang_nama':'Laptop Dell Inspiron','barang_ikon':'💻','tipe':'masuk','jumlah':20,'stok_sebelum':0,'stok_sesudah':20,'keterangan':'Pembelian awal','tanggal':DateTime.now().subtract(const Duration(days:30)).toIso8601String(),'created_at':now},
      {'barang_id':1,'barang_nama':'Laptop Dell Inspiron','barang_ikon':'💻','tipe':'keluar','jumlah':5,'stok_sebelum':20,'stok_sesudah':15,'keterangan':'Distribusi IT','tanggal':DateTime.now().subtract(const Duration(days:15)).toIso8601String(),'created_at':now},
      {'barang_id':3,'barang_nama':'Kertas HVS A4 80gr','barang_ikon':'📄','tipe':'masuk','jumlah':300,'stok_sebelum':0,'stok_sesudah':300,'keterangan':'Pembelian bulanan','tanggal':DateTime.now().subtract(const Duration(days:20)).toIso8601String(),'created_at':now},
      {'barang_id':3,'barang_nama':'Kertas HVS A4 80gr','barang_ikon':'📄','tipe':'keluar','jumlah':100,'stok_sebelum':300,'stok_sesudah':200,'keterangan':'Cetak laporan','tanggal':DateTime.now().subtract(const Duration(days:5)).toIso8601String(),'created_at':now},
      {'barang_id':6,'barang_nama':'Air Mineral 600ml','barang_ikon':'💧','tipe':'masuk','jumlah':200,'stok_sebelum':0,'stok_sesudah':200,'keterangan':'Stok bulanan','tanggal':DateTime.now().subtract(const Duration(days:25)).toIso8601String(),'created_at':now},
      {'barang_id':6,'barang_nama':'Air Mineral 600ml','barang_ikon':'💧','tipe':'keluar','jumlah':80,'stok_sebelum':200,'stok_sesudah':120,'keterangan':'Konsumsi harian','tanggal':DateTime.now().subtract(const Duration(days:2)).toIso8601String(),'created_at':now},
    ];
    for (final t in list) {
      await db.insert('transaksi', t, conflictAlgorithm: ConflictAlgorithm.ignore);
    }
  }

  // ==================== USER CRUD ====================
  Future<User?> getUserByUsername(String username) async {
    final db = await database;
    final maps = await db.query('users', where: 'username = ? AND is_active = 1', whereArgs: [username]);
    if (maps.isEmpty) return null;
    return User.fromMap(maps.first);
  }

  Future<User?> getUserById(int id) async {
    final db = await database;
    final maps = await db.query('users', where: 'id = ?', whereArgs: [id]);
    if (maps.isEmpty) return null;
    return User.fromMap(maps.first);
  }

  Future<List<User>> getAllUsers() async {
    final db = await database;
    final maps = await db.query('users', orderBy: 'created_at ASC');
    return maps.map((m) => User.fromMap(m)).toList();
  }

  Future<int> insertUser(User user) async {
    final db = await database;
    int id = await db.insert('users', user.toMap(), conflictAlgorithm: ConflictAlgorithm.abort);
    final data = user.toMap()..['id'] = id;
    _syncToSupabase('users', data, id: id);
    return id;
  }

  Future<int> updateUser(User user) async {
    final db = await database;
    int result = await db.update('users', user.toMap(), where: 'id = ?', whereArgs: [user.id]);
    _syncToSupabase('users', user.toMap(), id: user.id);
    return result;
  }

  Future<void> updateLastLogin(int userId) async {
    final db = await database;
    await db.update('users', {'last_login': DateTime.now().toIso8601String()}, where: 'id = ?', whereArgs: [userId]);
    final user = await getUserById(userId);
    if (user != null) _syncToSupabase('users', user.toMap(), id: userId);
  }

  Future<void> updateUserPassword(int userId, String newHash) async {
    final db = await database;
    await db.update('users', {'password_hash': newHash}, where: 'id = ?', whereArgs: [userId]);
    final user = await getUserById(userId);
    if (user != null) _syncToSupabase('users', user.toMap(), id: userId);
  }

  Future<int> deleteUser(int id) async {
    final db = await database;
    await _deleteFromSupabase('users', id);
    return await db.delete('users', where: 'id = ?', whereArgs: [id]);
  }

  // ==================== SUPPLIER CRUD ====================
  Future<List<Supplier>> getAllSuppliers() async {
    final db = await database;
    final maps = await db.query('suppliers', orderBy: 'created_at DESC');
    return maps.map((m) => Supplier.fromMap(m)).toList();
  }

  Future<List<Supplier>> searchSuppliers(String q) async {
    final db = await database;
    final maps = await db.query('suppliers', where: 'nama LIKE ? OR kontak LIKE ? OR kota LIKE ?', whereArgs: ['%$q%', '%$q%', '%$q%'], orderBy: 'nama ASC');
    return maps.map((m) => Supplier.fromMap(m)).toList();
  }

  Future<int> insertSupplier(Supplier s) async {
    final db = await database;
    int id = await db.insert('suppliers', s.toMap());
    final data = s.toMap()..['id'] = id;
    _syncToSupabase('suppliers', data, id: id);
    return id;
  }

  Future<int> updateSupplier(Supplier s) async {
    final db = await database;
    int result = await db.update('suppliers', s.toMap(), where: 'id = ?', whereArgs: [s.id]);
    _syncToSupabase('suppliers', s.toMap(), id: s.id);
    return result;
  }

  Future<int> deleteSupplier(int id) async {
    final db = await database;
    await _deleteFromSupabase('suppliers', id);
    return await db.delete('suppliers', where: 'id = ?', whereArgs: [id]);
  }

  // ==================== BARANG CRUD ====================
  Future<List<Barang>> getAllBarang() async {
    final db = await database;
    final maps = await db.query('barang', orderBy: 'nama ASC');
    return maps.map((m) => Barang.fromMap(m)).toList();
  }

  Future<List<Barang>> searchBarang(String q) async {
    final db = await database;
    final maps = await db.query('barang', where: 'nama LIKE ? OR jenis LIKE ?', whereArgs: ['%$q%', '%$q%'], orderBy: 'nama ASC');
    return maps.map((m) => Barang.fromMap(m)).toList();
  }

  Future<List<Barang>> getBarangByJenis(String jenis) async {
    final db = await database;
    final maps = await db.query('barang', where: 'jenis = ?', whereArgs: [jenis], orderBy: 'nama ASC');
    return maps.map((m) => Barang.fromMap(m)).toList();
  }

  Future<Barang?> getBarangById(int id) async {
    final db = await database;
    final maps = await db.query('barang', where: 'id = ?', whereArgs: [id]);
    if (maps.isEmpty) return null;
    return Barang.fromMap(maps.first);
  }

  Future<int> insertBarang(Barang b) async {
    final db = await database;
    int id = await db.insert('barang', b.toMap());
    final data = b.toMap()..['id'] = id;
    _syncToSupabase('barang', data, id: id);
    return id;
  }

  Future<int> updateBarang(Barang b) async {
    final db = await database;
    int result = await db.update('barang', b.toMap(), where: 'id = ?', whereArgs: [b.id]);
    _syncToSupabase('barang', b.toMap(), id: b.id);
    return result;
  }

  Future<int> updateStokBarang(int barangId, int stokBaru) async {
    final db = await database;
    await db.update('barang', {'stok': stokBaru, 'updated_at': DateTime.now().toIso8601String()}, where: 'id = ?', whereArgs: [barangId]);
    final barang = await getBarangById(barangId);
    if (barang != null) _syncToSupabase('barang', barang.toMap(), id: barangId);
    return 1;
  }

  Future<int> deleteBarang(int id) async {
    final db = await database;
    await _deleteFromSupabase('barang', id);
    return await db.delete('barang', where: 'id = ?', whereArgs: [id]);
  }

  // ==================== TRANSAKSI CRUD ====================
  Future<List<Transaksi>> getAllTransaksi() async {
    final db = await database;
    final maps = await db.query('transaksi', orderBy: 'tanggal DESC');
    return maps.map((m) => Transaksi.fromMap(m)).toList();
  }

  Future<List<Transaksi>> getTransaksiByTipe(TipeTransaksi tipe) async {
    final db = await database;
    final t = tipe == TipeTransaksi.masuk ? 'masuk' : 'keluar';
    final maps = await db.query('transaksi', where: 'tipe = ?', whereArgs: [t], orderBy: 'tanggal DESC');
    return maps.map((m) => Transaksi.fromMap(m)).toList();
  }

  Future<int> insertTransaksi(Transaksi t) async {
    final db = await database;
    int id = await db.insert('transaksi', t.toMap());
    final data = t.toMap()..['id'] = id;
    _syncToSupabase('transaksi', data, id: id);
    return id;
  }

  // ==================== DASHBOARD & LAPORAN ====================
  Future<Map<String, int>> getDashboardStats() async {
    final db = await database;
    final stok   = await db.rawQuery("SELECT COALESCE(SUM(stok),0) as v FROM barang");
    final masuk  = await db.rawQuery("SELECT COALESCE(SUM(jumlah),0) as v FROM transaksi WHERE tipe='masuk'");
    final keluar = await db.rawQuery("SELECT COALESCE(SUM(jumlah),0) as v FROM transaksi WHERE tipe='keluar'");
    final jenis  = await db.rawQuery("SELECT COUNT(*) as v FROM barang");
    final sup    = await db.rawQuery("SELECT COUNT(*) as v FROM suppliers WHERE status='aktif'");
    final rendah = await db.rawQuery("SELECT COUNT(*) as v FROM barang WHERE stok <= stok_minimum");
    return {
      'total_stok':    (stok.first['v'] as int?) ?? 0,
      'total_masuk':   (masuk.first['v'] as int?) ?? 0,
      'total_keluar':  (keluar.first['v'] as int?) ?? 0,
      'jenis_barang':  (jenis.first['v'] as int?) ?? 0,
      'supplier_aktif':(sup.first['v'] as int?) ?? 0,
      'stok_rendah':   (rendah.first['v'] as int?) ?? 0,
    };
  }

  Future<List<Map<String, dynamic>>> getChartData7Hari() async {
    final db = await database;
    final results = <Map<String, dynamic>>[];
    for (int i = 6; i >= 0; i--) {
      final date = DateTime.now().subtract(Duration(days: i));
      final dateStr = '${date.year}-${date.month.toString().padLeft(2,'0')}-${date.day.toString().padLeft(2,'0')}';
      final m = await db.rawQuery("SELECT COALESCE(SUM(jumlah),0) as v FROM transaksi WHERE tipe='masuk' AND DATE(tanggal)=?", [dateStr]);
      final k = await db.rawQuery("SELECT COALESCE(SUM(jumlah),0) as v FROM transaksi WHERE tipe='keluar' AND DATE(tanggal)=?", [dateStr]);
      results.add({'tanggal': date, 'masuk': (m.first['v'] as int?) ?? 0, 'keluar': (k.first['v'] as int?) ?? 0});
    }
    return results;
  }

  Future<List<Map<String, dynamic>>> getLaporanPerBarang() async {
    final db = await database;
    final barangList = await db.query('barang', orderBy: 'nama ASC');
    final result = <Map<String, dynamic>>[];
    for (final b in barangList) {
      final id = b['id'] as int;
      final m = await db.rawQuery("SELECT COALESCE(SUM(jumlah),0) as v FROM transaksi WHERE barang_id=? AND tipe='masuk'", [id]);
      final k = await db.rawQuery("SELECT COALESCE(SUM(jumlah),0) as v FROM transaksi WHERE barang_id=? AND tipe='keluar'", [id]);
      result.add({'id':id,'nama':b['nama'],'ikon':b['ikon'],'jenis':b['jenis'],'satuan':b['satuan'],'stok':b['stok'],'total_masuk':(m.first['v'] as int?)??0,'total_keluar':(k.first['v'] as int?)??0});
    }
    return result;
  }

  // ==================== BACKUP & RESET ====================
  Future<String?> backupDatabase() async {
    try {
      final src = File(await getDatabasePath());
      if (!await src.exists()) return null;
      final docs = await getApplicationDocumentsDirectory();
      final name = 'backup_inventaris_${DateTime.now().millisecondsSinceEpoch}.db';
      await src.copy('${docs.path}/$name');
      return '${docs.path}/$name';
    } catch (_) { return null; }
  }

  Future<void> resetDatabase() async {
    await closeDatabase();
    final file = File(await getDatabasePath());
    if (await file.exists()) await file.delete();
    _database = await _initDatabase();
  }

  Future<void> closeDatabase() async {
    await _database?.close();
    _database = null;
  }
}
// lib/models/barang_model.dart
class Barang {
  final int? id;
  final String nama;
  final String jenis;
  final String satuan;
  final int stok;
  final int stokMinimum;
  final String? fotoPath;
  final String ikon; // emoji fallback
  final int? supplierId;
  final String? supplierNama;
  final String keterangan;
  final DateTime createdAt;
  final DateTime updatedAt;

  Barang({
    this.id,
    required this.nama,
    required this.jenis,
    this.satuan = 'pcs',
    this.stok = 0,
    this.stokMinimum = 5,
    this.fotoPath,
    this.ikon = '📦',
    this.supplierId,
    this.supplierNama,
    this.keterangan = '',
    DateTime? createdAt,
    DateTime? updatedAt,
  })  : createdAt = createdAt ?? DateTime.now(),
        updatedAt = updatedAt ?? DateTime.now();

  factory Barang.fromMap(Map<String, dynamic> map) {
    return Barang(
      id: map['id'] as int?,
      nama: map['nama'] as String,
      jenis: map['jenis'] as String,
      satuan: map['satuan'] as String? ?? 'pcs',
      stok: map['stok'] as int? ?? 0,
      stokMinimum: map['stok_minimum'] as int? ?? 5,
      fotoPath: map['foto_path'] as String?,
      ikon: map['ikon'] as String? ?? '📦',
      supplierId: map['supplier_id'] as int?,
      supplierNama: map['supplier_nama'] as String?,
      keterangan: map['keterangan'] as String? ?? '',
      createdAt: DateTime.tryParse(map['created_at'] as String? ?? '') ?? DateTime.now(),
      updatedAt: DateTime.tryParse(map['updated_at'] as String? ?? '') ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      if (id != null) 'id': id,
      'nama': nama,
      'jenis': jenis,
      'satuan': satuan,
      'stok': stok,
      'stok_minimum': stokMinimum,
      'foto_path': fotoPath,
      'ikon': ikon,
      'supplier_id': supplierId,
      'supplier_nama': supplierNama,
      'keterangan': keterangan,
      'created_at': createdAt.toIso8601String(),
      'updated_at': DateTime.now().toIso8601String(),
    };
  }

  bool get isStokRendah => stok <= stokMinimum;
  bool get isStokKosong => stok == 0;

  double get stokPercentage {
    if (stokMinimum == 0) return 1.0;
    final max = stokMinimum * 4;
    return (stok / max).clamp(0.0, 1.0);
  }

  Barang copyWith({
    int? id, String? nama, String? jenis, String? satuan, int? stok,
    int? stokMinimum, String? fotoPath, String? ikon, int? supplierId,
    String? supplierNama, String? keterangan,
  }) {
    return Barang(
      id: id ?? this.id,
      nama: nama ?? this.nama,
      jenis: jenis ?? this.jenis,
      satuan: satuan ?? this.satuan,
      stok: stok ?? this.stok,
      stokMinimum: stokMinimum ?? this.stokMinimum,
      fotoPath: fotoPath ?? this.fotoPath,
      ikon: ikon ?? this.ikon,
      supplierId: supplierId ?? this.supplierId,
      supplierNama: supplierNama ?? this.supplierNama,
      keterangan: keterangan ?? this.keterangan,
      createdAt: createdAt,
      updatedAt: DateTime.now(),
    );
  }
}
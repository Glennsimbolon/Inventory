// lib/models/transaksi_model.dart
enum TipeTransaksi { masuk, keluar }

class Transaksi {
  final int? id;
  final int barangId;
  final String barangNama;
  final String barangIkon;
  final TipeTransaksi tipe;
  final int jumlah;
  final int stokSebelum;
  final int stokSesudah;
  final String? keterangan;
  final String? nomorReferensi;
  final DateTime tanggal;
  final DateTime createdAt;

  Transaksi({
    this.id,
    required this.barangId,
    required this.barangNama,
    this.barangIkon = '📦',
    required this.tipe,
    required this.jumlah,
    required this.stokSebelum,
    required this.stokSesudah,
    this.keterangan,
    this.nomorReferensi,
    DateTime? tanggal,
    DateTime? createdAt,
  })  : tanggal = tanggal ?? DateTime.now(),
        createdAt = createdAt ?? DateTime.now();

  factory Transaksi.fromMap(Map<String, dynamic> map) {
    return Transaksi(
      id: map['id'] as int?,
      barangId: map['barang_id'] as int,
      barangNama: map['barang_nama'] as String,
      barangIkon: map['barang_ikon'] as String? ?? '📦',
      tipe: map['tipe'] == 'masuk' ? TipeTransaksi.masuk : TipeTransaksi.keluar,
      jumlah: map['jumlah'] as int,
      stokSebelum: map['stok_sebelum'] as int? ?? 0,
      stokSesudah: map['stok_sesudah'] as int? ?? 0,
      keterangan: map['keterangan'] as String?,
      nomorReferensi: map['nomor_referensi'] as String?,
      tanggal: DateTime.tryParse(map['tanggal'] as String? ?? '') ?? DateTime.now(),
      createdAt: DateTime.tryParse(map['created_at'] as String? ?? '') ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      if (id != null) 'id': id,
      'barang_id': barangId,
      'barang_nama': barangNama,
      'barang_ikon': barangIkon,
      'tipe': tipe == TipeTransaksi.masuk ? 'masuk' : 'keluar',
      'jumlah': jumlah,
      'stok_sebelum': stokSebelum,
      'stok_sesudah': stokSesudah,
      'keterangan': keterangan,
      'nomor_referensi': nomorReferensi,
      'tanggal': tanggal.toIso8601String(),
      'created_at': createdAt.toIso8601String(),
    };
  }
}

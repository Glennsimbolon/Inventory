// lib/models/supplier_model.dart
class Supplier {
  final int? id;
  final String nama;
  final String kontak;
  final String telepon;
  final String email;
  final String kota;
  final String alamat;
  final String status; // 'aktif' | 'nonaktif'
  final DateTime createdAt;

  Supplier({
    this.id,
    required this.nama,
    required this.kontak,
    required this.telepon,
    this.email = '',
    this.kota = '',
    this.alamat = '',
    this.status = 'aktif',
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  factory Supplier.fromMap(Map<String, dynamic> map) {
    return Supplier(
      id: map['id'] as int?,
      nama: map['nama'] as String,
      kontak: map['kontak'] as String,
      telepon: map['telepon'] as String,
      email: map['email'] as String? ?? '',
      kota: map['kota'] as String? ?? '',
      alamat: map['alamat'] as String? ?? '',
      status: map['status'] as String? ?? 'aktif',
      createdAt: DateTime.tryParse(map['created_at'] as String? ?? '') ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      if (id != null) 'id': id,
      'nama': nama,
      'kontak': kontak,
      'telepon': telepon,
      'email': email,
      'kota': kota,
      'alamat': alamat,
      'status': status,
      'created_at': createdAt.toIso8601String(),
    };
  }

  Supplier copyWith({
    int? id, String? nama, String? kontak, String? telepon,
    String? email, String? kota, String? alamat, String? status,
  }) {
    return Supplier(
      id: id ?? this.id,
      nama: nama ?? this.nama,
      kontak: kontak ?? this.kontak,
      telepon: telepon ?? this.telepon,
      email: email ?? this.email,
      kota: kota ?? this.kota,
      alamat: alamat ?? this.alamat,
      status: status ?? this.status,
      createdAt: createdAt,
    );
  }
}

// lib/utils/auth_service.dart
import 'package:shared_preferences/shared_preferences.dart';
import '../models/user_model.dart';
import '../database/database_helper.dart';

class AuthService {
  static final AuthService _instance = AuthService._internal();
  factory AuthService() => _instance;
  AuthService._internal();

  static const String _keyUserId       = 'session_user_id';
  static const String _keyUsername     = 'session_username';
  static const String _keyNamaLengkap  = 'session_nama_lengkap';
  static const String _keyRole         = 'session_role';
  static const String _keyIsLoggedIn   = 'session_is_logged_in';

  User? _currentUser;
  User? get currentUser => _currentUser;
  bool get isLoggedIn   => _currentUser != null;

  final _db = DatabaseHelper();

  // ── Login ─────────────────────────────────────────────────────
  Future<LoginResult> login(String username, String password) async {
    if (username.trim().isEmpty || password.isEmpty) {
      return LoginResult.error('Username dan password tidak boleh kosong.');
    }

    final user = await _db.getUserByUsername(username.trim().toLowerCase());

    if (user == null) {
      return LoginResult.error('Username tidak ditemukan.');
    }

    if (!user.isActive) {
      return LoginResult.error('Akun ini telah dinonaktifkan. Hubungi administrator.');
    }

    if (!user.verifyPassword(password)) {
      return LoginResult.error('Password salah. Silakan coba lagi.');
    }

    // Update last login
    await _db.updateLastLogin(user.id!);
    _currentUser = user.copyWith(lastLogin: DateTime.now());

    // Simpan sesi ke SharedPreferences
    await _saveSession(_currentUser!);

    return LoginResult.success(_currentUser!);
  }

  // ── Logout ────────────────────────────────────────────────────
  Future<void> logout() async {
    _currentUser = null;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_keyUserId);
    await prefs.remove(_keyUsername);
    await prefs.remove(_keyNamaLengkap);
    await prefs.remove(_keyRole);
    await prefs.setBool(_keyIsLoggedIn, false);
  }

  // ── Restore session saat app restart ─────────────────────────
  Future<bool> restoreSession() async {
    final prefs = await SharedPreferences.getInstance();
    final isLoggedIn = prefs.getBool(_keyIsLoggedIn) ?? false;
    if (!isLoggedIn) return false;

    final userId = prefs.getInt(_keyUserId);
    if (userId == null) return false;

    // Verifikasi user masih ada & aktif di database
    final user = await _db.getUserById(userId);
    if (user == null || !user.isActive) {
      await logout();
      return false;
    }

    _currentUser = user;
    return true;
  }

  // ── Simpan sesi ───────────────────────────────────────────────
  Future<void> _saveSession(User user) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_keyUserId,      user.id!);
    await prefs.setString(_keyUsername, user.username);
    await prefs.setString(_keyNamaLengkap, user.namaLengkap);
    await prefs.setString(_keyRole,     user.role);
    await prefs.setBool(_keyIsLoggedIn, true);
  }

  // ── Ganti password ────────────────────────────────────────────
  Future<String?> changePassword({
    required String currentPassword,
    required String newPassword,
    required String confirmPassword,
  }) async {
    if (_currentUser == null) return 'Sesi tidak valid.';
    if (!_currentUser!.verifyPassword(currentPassword)) {
      return 'Password saat ini salah.';
    }
    if (newPassword.length < 6) {
      return 'Password baru minimal 6 karakter.';
    }
    if (newPassword != confirmPassword) {
      return 'Konfirmasi password tidak cocok.';
    }
    final newHash = User.hashPassword(newPassword);
    await _db.updateUserPassword(_currentUser!.id!, newHash);
    _currentUser = _currentUser!.copyWith(passwordHash: newHash);
    return null; // null = sukses
  }
}

// ── Result wrapper ────────────────────────────────────────────────
class LoginResult {
  final bool success;
  final String? errorMessage;
  final User? user;

  const LoginResult._({required this.success, this.errorMessage, this.user});

  factory LoginResult.success(User user) =>
      LoginResult._(success: true, user: user);
  factory LoginResult.error(String message) =>
      LoginResult._(success: false, errorMessage: message);
}
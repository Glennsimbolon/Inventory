// lib/screens/profil_screen.dart
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../utils/auth_service.dart';
import '../theme/app_theme.dart';
import 'login_screen.dart';

class ProfilScreen extends StatefulWidget {
  const ProfilScreen({super.key});
  @override
  State<ProfilScreen> createState() => _ProfilScreenState();
}

class _ProfilScreenState extends State<ProfilScreen> {
  final _auth = AuthService();

  void _showGantiPassword() {
    final formKey    = GlobalKey<FormState>();
    final currentCtrl = TextEditingController();
    final newCtrl     = TextEditingController();
    final confirmCtrl = TextEditingController();
    bool obscureCur = true, obscureNew = true, obscureCon = true;
    String? errorMsg;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => Padding(
          padding: EdgeInsets.only(
              bottom: MediaQuery.of(ctx).viewInsets.bottom),
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Form(
              key: formKey,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(child: Container(
                      width: 36, height: 4,
                      decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(2)))),
                  const SizedBox(height: 20),
                  const Text('Ganti Password',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: AppColors.text1)),
                  const SizedBox(height: 20),

                  if (errorMsg != null) ...[
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                          color: AppColors.dangerLight,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: AppColors.danger.withOpacity(0.3))),
                      child: Row(children: [
                        const Icon(Icons.error_outline_rounded, color: AppColors.danger, size: 16),
                        const SizedBox(width: 8),
                        Expanded(child: Text(errorMsg!, style: const TextStyle(fontSize: 13, color: AppColors.danger))),
                      ]),
                    ),
                    const SizedBox(height: 14),
                  ],

                  _buildPassField('Password Saat Ini', currentCtrl, obscureCur,
                      () => setS(() => obscureCur = !obscureCur), true),
                  _buildPassField('Password Baru (min. 6 karakter)', newCtrl, obscureNew,
                      () => setS(() => obscureNew = !obscureNew), false),
                  _buildPassField('Konfirmasi Password Baru', confirmCtrl, obscureCon,
                      () => setS(() => obscureCon = !obscureCon), false),

                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () async {
                        if (!formKey.currentState!.validate()) return;
                        final err = await _auth.changePassword(
                          currentPassword: currentCtrl.text,
                          newPassword:     newCtrl.text,
                          confirmPassword: confirmCtrl.text,
                        );
                        if (err != null) {
                          setS(() => errorMsg = err);
                        } else {
                          Navigator.pop(ctx);
                          if (mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                              content: Text('Password berhasil diperbarui ✓'),
                              backgroundColor: AppColors.primary,
                              behavior: SnackBarBehavior.floating,
                            ));
                          }
                        }
                      },
                      child: const Text('Simpan Password'),
                    ),
                  ),
                  const SizedBox(height: 8),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildPassField(String label, TextEditingController ctrl,
      bool obscure, VoidCallback toggle, bool isRequired) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.text2)),
          const SizedBox(height: 6),
          TextFormField(
            controller: ctrl,
            obscureText: obscure,
            validator: (v) {
              if (v == null || v.isEmpty) return 'Wajib diisi';
              return null;
            },
            decoration: InputDecoration(
              suffixIcon: IconButton(
                icon: Icon(obscure ? Icons.visibility_outlined : Icons.visibility_off_outlined,
                    color: AppColors.text3, size: 18),
                onPressed: toggle,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _doLogout() async {
    final konfirmasi = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Konfirmasi Keluar',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
        content: const Text('Apakah Anda yakin ingin keluar dari aplikasi?',
            style: TextStyle(fontSize: 14, color: AppColors.text2)),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Batal')),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.danger),
            child: const Text('Keluar'),
          ),
        ],
      ),
    );
    if (konfirmasi == true) {
      await _auth.logout();
      if (mounted) {
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const LoginScreen()),
          (route) => false,
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = _auth.currentUser;
    if (user == null) return const SizedBox.shrink();

    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(
        title: const Text('Profil & Akun'),
        backgroundColor: AppColors.primary,
      ),
      body: ListView(
        children: [
          // ── Header Profil ────────────────────────────────────
          Container(
            width: double.infinity,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [AppColors.primary, AppColors.primaryLight],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            padding: const EdgeInsets.fromLTRB(24, 28, 24, 32),
            child: Column(
              children: [
                // Avatar
                Container(
                  width: 86, height: 86,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                          color: Colors.black.withOpacity(0.15),
                          blurRadius: 12, offset: const Offset(0, 4))
                    ],
                  ),
                  child: Center(
                    child: Text(
                      user.namaLengkap.isNotEmpty
                          ? user.namaLengkap[0].toUpperCase()
                          : '?',
                      style: const TextStyle(
                          fontSize: 36,
                          fontWeight: FontWeight.w800,
                          color: AppColors.primary),
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                Text(user.namaLengkap,
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.w700)),
                const SizedBox(height: 6),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(user.roleLabel,
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                          fontWeight: FontWeight.w600)),
                ),
              ],
            ),
          ),

          const SizedBox(height: 16),

          // ── Info Akun ────────────────────────────────────────
          _buildSection('Informasi Akun', [
            _infoTile(Icons.person_rounded, 'Username', '@${user.username}', AppColors.primary, AppColors.primaryLighter),
            _infoTile(Icons.email_rounded, 'Email', user.email ?? '-', AppColors.info, AppColors.infoLight),
            _infoTile(Icons.shield_rounded, 'Role', user.roleLabel, AppColors.success, AppColors.successLight),
            _infoTile(Icons.access_time_rounded, 'Login Terakhir',
                user.lastLogin != null
                    ? DateFormat('dd MMM yyyy, HH:mm', 'id_ID').format(user.lastLogin!)
                    : '-',
                AppColors.accent, AppColors.accentLight),
          ]),

          const SizedBox(height: 12),

          // ── Hak Akses ────────────────────────────────────────
          _buildSection('Hak Akses', [
            _accessTile('Lihat Dashboard & Laporan', true),
            _accessTile('Tambah & Edit Data Barang', user.canEdit),
            _accessTile('Catat Barang Masuk & Keluar', user.canEdit),
            _accessTile('Kelola Data Supplier', user.canEdit),
            _accessTile('Manajemen Pengguna', user.isAdmin),
            _accessTile('Reset & Backup Database', user.isAdmin),
          ]),

          const SizedBox(height: 12),

          // ── Aksi ─────────────────────────────────────────────
          _buildSection('Aksi', [
            _actionTile(Icons.lock_reset_rounded, AppColors.info, AppColors.infoLight,
                'Ganti Password', 'Perbarui password akun Anda', _showGantiPassword),
            _actionTile(Icons.logout_rounded, AppColors.danger, AppColors.dangerLight,
                'Keluar (Logout)', 'Akhiri sesi dan kembali ke halaman login', _doLogout,
                isLast: true),
          ]),

          const SizedBox(height: 24),
          Center(
            child: Text('Inventaris Barang v1.0.0',
                style: TextStyle(fontSize: 11, color: AppColors.text3.withOpacity(0.6))),
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }

  Widget _buildSection(String title, List<Widget> children) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(bottom: 8, left: 2),
            child: Text(title.toUpperCase(),
                style: const TextStyle(
                    fontSize: 11, fontWeight: FontWeight.w700,
                    color: AppColors.text3, letterSpacing: 0.5)),
          ),
          Container(
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppColors.border, width: 0.5),
              boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 6)],
            ),
            child: Column(children: children),
          ),
        ],
      ),
    );
  }

  Widget _infoTile(IconData icon, String label, String value, Color color, Color bg) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        children: [
          Container(
            width: 36, height: 36,
            decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(10)),
            child: Icon(icon, color: color, size: 17),
          ),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label, style: const TextStyle(fontSize: 11, color: AppColors.text3, fontWeight: FontWeight.w500)),
              Text(value, style: const TextStyle(fontSize: 13, color: AppColors.text1, fontWeight: FontWeight.w600)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _accessTile(String label, bool allowed) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      child: Row(
        children: [
          Icon(
            allowed ? Icons.check_circle_rounded : Icons.cancel_rounded,
            color: allowed ? AppColors.success : AppColors.text3,
            size: 18,
          ),
          const SizedBox(width: 10),
          Text(label,
              style: TextStyle(
                  fontSize: 13,
                  color: allowed ? AppColors.text1 : AppColors.text3,
                  fontWeight: FontWeight.w500)),
        ],
      ),
    );
  }

  Widget _actionTile(IconData icon, Color color, Color bg,
      String title, String subtitle, VoidCallback onTap, {bool isLast = false}) {
    return Column(
      children: [
        ListTile(
          onTap: onTap,
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          leading: Container(
            width: 38, height: 38,
            decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(10)),
            child: Icon(icon, color: color, size: 18),
          ),
          title: Text(title,
              style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: color == AppColors.danger ? AppColors.danger : AppColors.text1)),
          subtitle: Text(subtitle, style: const TextStyle(fontSize: 11, color: AppColors.text3)),
          trailing: const Icon(Icons.chevron_right_rounded, color: AppColors.text3, size: 18),
        ),
        if (!isLast) const Divider(color: AppColors.divider, height: 1, indent: 70),
      ],
    );
  }
}
// lib/screens/supplier_screen.dart
import 'package:flutter/material.dart';
import '../database/database_helper.dart';
import '../models/supplier_model.dart';
import '../theme/app_theme.dart';
import '../services/app_refresh.dart';

class SupplierScreen extends StatefulWidget {
  const SupplierScreen({super.key});
  @override
  State<SupplierScreen> createState() => _SupplierScreenState();
}

class _SupplierScreenState extends State<SupplierScreen> {
  final _db = DatabaseHelper();
  List<Supplier> _suppliers = [];
  bool _isLoading = true;
  final _searchCtrl = TextEditingController();

 @override
void initState() {
  super.initState();

  _loadSuppliers();
  AppRefresh.refreshNotifier.addListener(() {
  _loadSuppliers();
});
}

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadSuppliers([String query = '']) async {
    setState(() => _isLoading = true);
    final data = query.isEmpty ? await _db.getAllSuppliers() : await _db.searchSuppliers(query);
    if (mounted) setState(() { _suppliers = data; _isLoading = false; });
  }

  void _showFormDialog([Supplier? existing]) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (_) => _SupplierForm(
        supplier: existing,
        onSave: (s) async {
          if (existing == null) {
            await _db.insertSupplier(s);
          } else {
            await _db.updateSupplier(s);
          }
          if (mounted) {
            _loadSuppliers();
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(existing == null ? 'Supplier berhasil ditambahkan' : 'Supplier berhasil diperbarui'),
                backgroundColor: AppColors.primary,
                behavior: SnackBarBehavior.floating,
              ),
            );
          }
        },
      ),
    );
  }

  void _deleteSupplier(Supplier s) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Hapus Supplier'),
        content: Text('Yakin ingin menghapus ${s.nama}?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.danger),
            child: const Text('Hapus'),
          ),
        ],
      ),
    );
    if (confirm == true) {
      await _db.deleteSupplier(s.id!);
      _loadSuppliers();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(
        title: const Text('Data Supplier'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 8),
            child: TextButton.icon(
              onPressed: () => _showFormDialog(),
              icon: const Icon(Icons.add_rounded, color: Colors.white, size: 18),
              label: const Text('Tambah', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          // Search bar
          Container(
            margin: const EdgeInsets.all(16),
            padding: const EdgeInsets.symmetric(horizontal: 14),
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.border),
              boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 6)],
            ),
            child: Row(
              children: [
                const Icon(Icons.search_rounded, color: AppColors.text3, size: 20),
                const SizedBox(width: 8),
                Expanded(
                  child: TextField(
                    controller: _searchCtrl,
                    onChanged: (v) => _loadSuppliers(v),
                    decoration: const InputDecoration(
                      hintText: 'Cari nama, kontak, atau kota...',
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.symmetric(vertical: 12),
                    ),
                    style: const TextStyle(fontSize: 14),
                  ),
                ),
                if (_searchCtrl.text.isNotEmpty)
                  GestureDetector(
                    onTap: () { _searchCtrl.clear(); _loadSuppliers(); },
                    child: const Icon(Icons.close_rounded, color: AppColors.text3, size: 18),
                  ),
              ],
            ),
          ),
          // Stats bar
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
            child: Row(
              children: [
                _buildStatPill('Total ${_suppliers.length}', AppColors.primary, AppColors.primaryLighter),
                const SizedBox(width: 8),
                _buildStatPill('Aktif ${_suppliers.where((s) => s.status == 'aktif').length}', AppColors.success, AppColors.successLight),
                const SizedBox(width: 8),
                _buildStatPill('Nonaktif ${_suppliers.where((s) => s.status == 'nonaktif').length}', AppColors.text3, AppColors.bg),
              ],
            ),
          ),
          // Table header
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 16),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              color: AppColors.primary,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
            ),
            child: const Row(
              children: [
                Expanded(flex: 3, child: Text('Nama Supplier', style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700))),
                Expanded(flex: 2, child: Text('Kontak & Kota', style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700))),
                Expanded(flex: 1, child: Text('Status', style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700), textAlign: TextAlign.center)),
                SizedBox(width: 60, child: Text('Aksi', style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700), textAlign: TextAlign.center)),
              ],
            ),
          ),
          // Table body
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator(color: AppColors.primary))
                : _suppliers.isEmpty
                    ? _buildEmpty()
                    : Container(
                        margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                        decoration: BoxDecoration(
                          color: AppColors.surface,
                          borderRadius: const BorderRadius.vertical(bottom: Radius.circular(12)),
                          border: Border.all(color: AppColors.border, width: 0.5),
                          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8, offset: const Offset(0, 2))],
                        ),
                        child: ListView.separated(
                          itemCount: _suppliers.length,
                          separatorBuilder: (_, __) => const Divider(color: AppColors.divider, height: 1),
                          itemBuilder: (_, i) => _buildSupplierRow(_suppliers[i]),
                        ),
                      ),
          ),
        ],
      ),
    );
  }

  Widget _buildSupplierRow(Supplier s) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      child: Row(
        children: [
          Expanded(
            flex: 3,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(s.nama, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.text1)),
                if (s.telepon.isNotEmpty)
                  Text(s.telepon, style: const TextStyle(fontSize: 11, color: AppColors.text3)),
              ],
            ),
          ),
          Expanded(
            flex: 2,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(s.kontak, style: const TextStyle(fontSize: 12, color: AppColors.text2)),
                if (s.kota.isNotEmpty)
                  Text(s.kota, style: const TextStyle(fontSize: 11, color: AppColors.text3)),
              ],
            ),
          ),
          Expanded(
            flex: 1,
            child: Center(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                decoration: BoxDecoration(
                  color: s.status == 'aktif' ? AppColors.successLight : AppColors.dangerLight,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  s.status == 'aktif' ? 'Aktif' : 'Off',
                  style: TextStyle(
                    fontSize: 10, fontWeight: FontWeight.w700,
                    color: s.status == 'aktif' ? AppColors.success : AppColors.danger,
                  ),
                ),
              ),
            ),
          ),
          SizedBox(
            width: 60,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                GestureDetector(
                  onTap: () => _showFormDialog(s),
                  child: Container(
                    width: 28, height: 28,
                    decoration: BoxDecoration(color: AppColors.infoLight, borderRadius: BorderRadius.circular(7)),
                    child: const Icon(Icons.edit_rounded, size: 14, color: AppColors.info),
                  ),
                ),
                const SizedBox(width: 4),
                GestureDetector(
                  onTap: () => _deleteSupplier(s),
                  child: Container(
                    width: 28, height: 28,
                    decoration: BoxDecoration(color: AppColors.dangerLight, borderRadius: BorderRadius.circular(7)),
                    child: const Icon(Icons.delete_rounded, size: 14, color: AppColors.danger),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatPill(String label, Color color, Color bg) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(20)),
      child: Text(label, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: color)),
    );
  }

  Widget _buildEmpty() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.people_outline, size: 60, color: AppColors.text3),
          const SizedBox(height: 12),
          const Text('Belum ada supplier', style: TextStyle(fontSize: 15, color: AppColors.text3)),
          const SizedBox(height: 8),
          ElevatedButton(onPressed: () => _showFormDialog(), child: const Text('Tambah Supplier')),
        ],
      ),
    );
  }
}

// ==================== SUPPLIER FORM ====================
class _SupplierForm extends StatefulWidget {
  final Supplier? supplier;
  final Function(Supplier) onSave;
  const _SupplierForm({this.supplier, required this.onSave});
  @override
  State<_SupplierForm> createState() => _SupplierFormState();
}

class _SupplierFormState extends State<_SupplierForm> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _namaCtrl, _kontakCtrl, _telCtrl, _emailCtrl, _kotaCtrl, _alamatCtrl;
  String _status = 'aktif';

  @override
  void initState() {
    super.initState();
    final s = widget.supplier;
    _namaCtrl = TextEditingController(text: s?.nama ?? '');
    _kontakCtrl = TextEditingController(text: s?.kontak ?? '');
    _telCtrl = TextEditingController(text: s?.telepon ?? '');
    _emailCtrl = TextEditingController(text: s?.email ?? '');
    _kotaCtrl = TextEditingController(text: s?.kota ?? '');
    _alamatCtrl = TextEditingController(text: s?.alamat ?? '');
    _status = s?.status ?? 'aktif';
  }

  @override
  void dispose() {
    for (final c in [_namaCtrl, _kontakCtrl, _telCtrl, _emailCtrl, _kotaCtrl, _alamatCtrl]) { c.dispose(); }
    super.dispose();
  }

  void _save() {
    if (!_formKey.currentState!.validate()) return;
    final s = Supplier(
      id: widget.supplier?.id,
      nama: _namaCtrl.text.trim(),
      kontak: _kontakCtrl.text.trim(),
      telepon: _telCtrl.text.trim(),
      email: _emailCtrl.text.trim(),
      kota: _kotaCtrl.text.trim(),
      alamat: _alamatCtrl.text.trim(),
      status: _status,
    );
    Navigator.pop(context);
    widget.onSave(s);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Center(child: Container(width: 36, height: 4, decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(2)))),
                const SizedBox(height: 20),
                Text(widget.supplier == null ? 'Tambah Supplier Baru' : 'Edit Supplier',
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: AppColors.text1)),
                const SizedBox(height: 20),
                _buildField('Nama Perusahaan *', _namaCtrl, 'PT / CV / UD...', required: true),
                _buildField('Nama Kontak (PIC) *', _kontakCtrl, 'Nama lengkap', required: true),
                _buildField('Nomor Telepon *', _telCtrl, '08xx-xxxx-xxxx', required: true, keyboardType: TextInputType.phone),
                _buildField('Email', _emailCtrl, 'email@perusahaan.com', keyboardType: TextInputType.emailAddress),
                _buildField('Kota', _kotaCtrl, 'Jakarta, Surabaya, Bandung...'),
                _buildField('Alamat Lengkap', _alamatCtrl, 'Jalan, nomor, kelurahan...', maxLines: 2),
                const SizedBox(height: 4),
                const Text('Status', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.text2)),
                const SizedBox(height: 6),
                Row(
                  children: [
                    _buildStatusOption('aktif', 'Aktif', AppColors.success, AppColors.successLight),
                    const SizedBox(width: 10),
                    _buildStatusOption('nonaktif', 'Nonaktif', AppColors.danger, AppColors.dangerLight),
                  ],
                ),
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _save,
                    child: Text(widget.supplier == null ? 'Simpan Supplier' : 'Update Supplier'),
                  ),
                ),
                const SizedBox(height: 8),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildField(String label, TextEditingController ctrl, String hint,
      {bool required = false, TextInputType? keyboardType, int maxLines = 1}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.text2)),
          const SizedBox(height: 6),
          TextFormField(
            controller: ctrl,
            keyboardType: keyboardType,
            maxLines: maxLines,
            validator: required ? (v) => (v == null || v.isEmpty) ? 'Wajib diisi' : null : null,
            decoration: InputDecoration(hintText: hint),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusOption(String value, String label, Color color, Color bg) {
    final selected = _status == value;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _status = value),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: selected ? bg : AppColors.bg,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: selected ? color : AppColors.border, width: selected ? 2 : 1),
          ),
          child: Center(
            child: Text(label, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: selected ? color : AppColors.text3)),
          ),
        ),
      ),
    );
  }
}
// lib/screens/barang_keluar_screen.dart
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../database/database_helper.dart';
import '../models/barang_model.dart';
import '../models/transaksi_model.dart';
import '../theme/app_theme.dart';
import '../widgets/transaksi_form.dart';
import '../widgets/riwayat_transaksi.dart';
import '../services/app_refresh.dart';

class BarangKeluarScreen extends StatefulWidget {
  const BarangKeluarScreen({super.key});
  @override
  State<BarangKeluarScreen> createState() => _BarangKeluarScreenState();
}

class _BarangKeluarScreenState extends State<BarangKeluarScreen> {
  final _db = DatabaseHelper();
  List<Barang> _barangList = [];
  List<Barang> _filtered = [];
  bool _isLoading = true;
  final _searchCtrl = TextEditingController();

  @override
void initState() {
  super.initState();

  _loadData();

  AppRefresh.refreshNotifier.addListener(() {
    _loadData();
  });
}

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    final data = await _db.getAllBarang();
    if (mounted) {
      setState(() {
        _barangList = data;
        _filtered = data;
        _isLoading = false;
      });
    }
  }

  void _filter(String q) {
    setState(() {
      _filtered = q.isEmpty ? _barangList : _barangList.where((b) => b.nama.toLowerCase().contains(q.toLowerCase())).toList();
    });
  }

  void _showKeluarDialog(Barang b) {
    if (b.isStokKosong) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('${b.nama} stok sudah habis!'),
        backgroundColor: AppColors.danger,
        behavior: SnackBarBehavior.floating,
      ));
      return;
    }
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (_) => TransaksiForm(
        barang: b,
        tipe: TipeTransaksi.keluar,
        onSave: (jumlah, ket, noRef) async {
          final stokBaru = b.stok - jumlah;
          await _db.updateStokBarang(b.id!, stokBaru);
          await _db.insertTransaksi(Transaksi(
            barangId: b.id!,
            barangNama: b.nama,
            barangIkon: b.ikon,
            tipe: TipeTransaksi.keluar,
            jumlah: jumlah,
            stokSebelum: b.stok,
            stokSesudah: stokBaru,
            keterangan: ket,
            nomorReferensi: noRef,
          ));
          AppRefresh.refreshAll();
          if (mounted) {
            _loadData();
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: Text('-$jumlah ${b.satuan} ${b.nama} berhasil keluar. Sisa: $stokBaru ${b.satuan}'),
              backgroundColor: AppColors.danger,
              behavior: SnackBarBehavior.floating,
            ));
          }
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(
        title: const Text('Barang Keluar'),
        backgroundColor: AppColors.danger,
        actions: [
          IconButton(
            icon: const Icon(Icons.history_rounded, color: Colors.white),
            onPressed: () => _showHistory(),
            tooltip: 'Riwayat',
          ),
        ],
      ),
      body: Column(
        children: [
          Container(
            margin: const EdgeInsets.all(16),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [AppColors.danger, Color(0xFFB91C1C)]),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Row(
              children: [
                const Icon(Icons.arrow_upward_rounded, color: Colors.white, size: 28),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Catat Barang Keluar', style: TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w700)),
                      Text('Pilih barang yang akan dikeluarkan dari gudang\n${DateFormat('dd MMMM yyyy', 'id_ID').format(DateTime.now())}',
                          style: const TextStyle(color: Colors.white70, fontSize: 12)),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Container(
            margin: const EdgeInsets.fromLTRB(16, 0, 16, 12),
            padding: const EdgeInsets.symmetric(horizontal: 14),
            decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.border)),
            child: Row(
              children: [
                const Icon(Icons.search_rounded, color: AppColors.text3, size: 20),
                const SizedBox(width: 8),
                Expanded(
                  child: TextField(
                    controller: _searchCtrl,
                    onChanged: _filter,
                    decoration: const InputDecoration(hintText: 'Cari barang...', border: InputBorder.none, contentPadding: EdgeInsets.symmetric(vertical: 12)),
                    style: const TextStyle(fontSize: 14),
                  ),
                ),
              ],
            ),
          ),
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 16),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: const BoxDecoration(
              color: AppColors.danger,
              borderRadius: BorderRadius.vertical(top: Radius.circular(12)),
            ),
            child: const Row(
              children: [
                Expanded(flex: 3, child: Text('Nama Barang', style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700))),
                Expanded(flex: 2, child: Text('Stok Tersedia', style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700), textAlign: TextAlign.center)),
                SizedBox(width: 80, child: Text('Aksi', style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700), textAlign: TextAlign.center)),
              ],
            ),
          ),
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator(color: AppColors.danger))
                : _filtered.isEmpty
                    ? const Center(child: Text('Tidak ada barang', style: TextStyle(color: AppColors.text3)))
                    : Container(
                        margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                        decoration: BoxDecoration(
                          color: AppColors.surface,
                          borderRadius: const BorderRadius.vertical(bottom: Radius.circular(12)),
                          border: Border.all(color: AppColors.border, width: 0.5),
                          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8, offset: const Offset(0, 2))],
                        ),
                        child: ListView.separated(
                          itemCount: _filtered.length,
                          separatorBuilder: (_, __) => const Divider(color: AppColors.divider, height: 1),
                          itemBuilder: (_, i) => _buildRow(_filtered[i]),
                        ),
                      ),
          ),
        ],
      ),
    );
  }

  Widget _buildRow(Barang b) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      child: Row(
        children: [
          Container(
            width: 34, height: 34,
            decoration: BoxDecoration(
              color: b.isStokKosong ? AppColors.dangerLight : AppColors.primaryLighter,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Center(child: Text(b.ikon, style: const TextStyle(fontSize: 16))),
          ),
          const SizedBox(width: 10),
          Expanded(
            flex: 3,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(b.nama, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.text1)),
                Text('${b.jenis} • ${b.satuan}', style: const TextStyle(fontSize: 11, color: AppColors.text3)),
              ],
            ),
          ),
          Expanded(
            flex: 2,
            child: Column(
              children: [
                Text('${b.stok}', style: TextStyle(
                  fontSize: 16, fontWeight: FontWeight.w800,
                  color: b.isStokKosong ? AppColors.danger : (b.isStokRendah ? AppColors.warning : AppColors.primary),
                ), textAlign: TextAlign.center),
                Text(b.satuan, style: const TextStyle(fontSize: 10, color: AppColors.text3), textAlign: TextAlign.center),
              ],
            ),
          ),
          SizedBox(
            width: 80,
            child: ElevatedButton(
              onPressed: b.isStokKosong ? null : () => _showKeluarDialog(b),
              style: ElevatedButton.styleFrom(
                backgroundColor: b.isStokKosong ? AppColors.text3 : AppColors.danger,
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                minimumSize: Size.zero,
              ),
              child: Text(b.isStokKosong ? 'Habis' : '- Keluar', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700)),
            ),
          ),
        ],
      ),
    );
  }

  void _showHistory() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      isScrollControlled: true,
      builder: (_) => DraggableScrollableSheet(
        initialChildSize: 0.7,
        maxChildSize: 0.92,
        minChildSize: 0.4,
        expand: false,
        builder: (_, ctrl) => RiwayatTransaksi(tipe: TipeTransaksi.keluar, scrollController: ctrl),
      ),
    );
  }
}
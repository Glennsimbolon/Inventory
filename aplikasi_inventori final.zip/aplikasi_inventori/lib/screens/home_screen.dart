// lib/screens/home_screen.dart
import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../utils/auth_service.dart';
import 'dashboard_screen.dart';
import 'supplier_screen.dart';
import 'barang_screen.dart';
import 'barang_masuk_screen.dart';
import 'barang_keluar_screen.dart';
import 'laporan_screen.dart';
import 'profil_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;

  final List<Widget> _screens = const [
    DashboardScreen(),
    SupplierScreen(),
    BarangScreen(),
    BarangMasukScreen(),
    BarangKeluarScreen(),
    LaporanScreen(),
    ProfilScreen(),
  ];

  final List<_NavItem> _navItems = const [
    _NavItem(icon: Icons.dashboard_outlined,   activeIcon: Icons.dashboard_rounded,     label: 'Dashboard', color: AppColors.primary),
    _NavItem(icon: Icons.people_outline,       activeIcon: Icons.people_rounded,        label: 'Supplier',  color: AppColors.primary),
    _NavItem(icon: Icons.inventory_2_outlined, activeIcon: Icons.inventory_2_rounded,   label: 'Barang',    color: AppColors.primary),
    _NavItem(icon: Icons.south_rounded,        activeIcon: Icons.south_rounded,         label: 'Masuk',     color: AppColors.success),
    _NavItem(icon: Icons.north_rounded,        activeIcon: Icons.north_rounded,         label: 'Keluar',    color: AppColors.danger),
    _NavItem(icon: Icons.bar_chart_outlined,   activeIcon: Icons.bar_chart_rounded,     label: 'Laporan',   color: AppColors.info),
    _NavItem(icon: Icons.person_outline,       activeIcon: Icons.person_rounded,        label: 'Profil',    color: AppColors.accent),
  ];

  @override
  Widget build(BuildContext context) {
    final user = AuthService().currentUser;

    return Scaffold(
      body: IndexedStack(index: _currentIndex, children: _screens),
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          color: AppColors.surface,
          border: Border(top: BorderSide(color: AppColors.border, width: 0.5)),
          boxShadow: [
            BoxShadow(color: Color(0x0D000000), blurRadius: 16, offset: Offset(0, -4))
          ],
        ),
        child: SafeArea(
          child: SizedBox(
            height: 62,
            child: Row(
              children: List.generate(_navItems.length, (i) {
                final item    = _navItems[i];
                final isActive = _currentIndex == i;
                // index 6 = Profil → tampilkan inisial user
                if (i == 6) {
                  return Expanded(
                    child: GestureDetector(
                      onTap: () => setState(() => _currentIndex = i),
                      behavior: HitTestBehavior.opaque,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          AnimatedContainer(
                            duration: const Duration(milliseconds: 200),
                            padding: const EdgeInsets.all(4),
                            decoration: BoxDecoration(
                              color: isActive
                                  ? item.color.withOpacity(0.12)
                                  : Colors.transparent,
                              shape: BoxShape.circle,
                            ),
                            child: CircleAvatar(
                              radius: 13,
                              backgroundColor: isActive
                                  ? item.color
                                  : AppColors.border,
                              child: Text(
                                user?.namaLengkap.isNotEmpty == true
                                    ? user!.namaLengkap[0].toUpperCase()
                                    : 'U',
                                style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w700,
                                    color: isActive ? Colors.white : AppColors.text3),
                              ),
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(item.label,
                              style: TextStyle(
                                  fontSize: 10,
                                  fontWeight: isActive ? FontWeight.w700 : FontWeight.w400,
                                  color: isActive ? item.color : AppColors.text3)),
                        ],
                      ),
                    ),
                  );
                }
                return Expanded(
                  child: GestureDetector(
                    onTap: () => setState(() => _currentIndex = i),
                    behavior: HitTestBehavior.opaque,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: isActive
                                ? item.color.withOpacity(0.12)
                                : Colors.transparent,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Icon(
                            isActive ? item.activeIcon : item.icon,
                            color: isActive ? item.color : AppColors.text3,
                            size: 21,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(item.label,
                            style: TextStyle(
                                fontSize: 10,
                                fontWeight: isActive
                                    ? FontWeight.w700
                                    : FontWeight.w400,
                                color: isActive ? item.color : AppColors.text3)),
                      ],
                    ),
                  ),
                );
              }),
            ),
          ),
        ),
      ),
    );
  }
}

class _NavItem {
  final IconData icon, activeIcon;
  final String   label;
  final Color    color;
  const _NavItem({
    required this.icon,
    required this.activeIcon,
    required this.label,
    required this.color,
  });
}
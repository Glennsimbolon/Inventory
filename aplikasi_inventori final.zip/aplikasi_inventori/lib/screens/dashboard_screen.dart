// lib/screens/dashboard_screen.dart
import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:intl/intl.dart';
import '../database/database_helper.dart';
import '../models/transaksi_model.dart';
import '../theme/app_theme.dart';
import '../widgets/stat_card_widget.dart';
import '../services/app_refresh.dart';
class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final _db = DatabaseHelper();
  Map<String, int> _stats = {};
  List<Map<String, dynamic>> _chartData = [];
  List<Transaksi> _aktivitasTerbaru = [];
  bool _isLoading = true;

  @override
void initState() {
  super.initState();

  _loadData();

  AppRefresh.refreshNotifier.addListener(() {
    _loadData();
  });
}

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    final stats = await _db.getDashboardStats();
    final chart = await _db.getChartData7Hari();
    final aktivitas = await _db.getAllTransaksi();
    if (mounted) {
      setState(() {
        _stats = stats;
        _chartData = chart;
        _aktivitasTerbaru = aktivitas.take(8).toList();
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: _loadData,
      color: AppColors.primary,
      child: _isLoading
          ? const Center(child: CircularProgressIndicator(color: AppColors.primary))
          : CustomScrollView(
              slivers: [
                _buildAppBar(),
                SliverToBoxAdapter(child: _buildStatsRow()),
                SliverToBoxAdapter(child: _buildChart()),
                SliverToBoxAdapter(child: _buildStokRendahAlert()),
                SliverToBoxAdapter(child: _buildAktivitasTerbaru()),
                const SliverToBoxAdapter(child: SizedBox(height: 20)),
              ],
            ),
    );
  }

  Widget _buildAppBar() {
    return SliverAppBar(
      expandedHeight: 160,
      pinned: true,
      backgroundColor: AppColors.primary,
      flexibleSpace: FlexibleSpaceBar(
        background: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [AppColors.primaryLight, AppColors.primaryDark],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          padding: const EdgeInsets.fromLTRB(20, 60, 20, 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Row(
                children: [
                  const CircleAvatar(
                    backgroundColor: Colors.white24,
                    radius: 20,
                    child: Text('AD', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13)),
                  ),
                  const SizedBox(width: 10),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(DateFormat('EEEE, d MMMM yyyy', 'id_ID').format(DateTime.now()),
                          style: const TextStyle(color: Colors.white70, fontSize: 12)),
                      const Text('Selamat Datang, Admin',
                          style: TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w700)),
                    ],
                  ),
                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.inventory_2_outlined, color: Colors.white, size: 14),
                        const SizedBox(width: 4),
                        Text('${_stats['jenis_barang'] ?? 0} Jenis',
                            style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600)),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatsRow() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Ringkasan Stok', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: AppColors.text1)),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(child: StatCardWidget(
                label: 'Total Stok',
                value: '${_stats['total_stok'] ?? 0}',
                icon: Icons.inventory_2_rounded,
                color: AppColors.primary,
                bgColor: AppColors.primaryLighter,
              )),
              const SizedBox(width: 10),
              Expanded(child: StatCardWidget(
                label: 'Barang Masuk',
                value: '${_stats['total_masuk'] ?? 0}',
                icon: Icons.arrow_downward_rounded,
                color: AppColors.success,
                bgColor: AppColors.successLight,
                trend: '▲',
                trendColor: AppColors.success,
              )),
              const SizedBox(width: 10),
              Expanded(child: StatCardWidget(
                label: 'Barang Keluar',
                value: '${_stats['total_keluar'] ?? 0}',
                icon: Icons.arrow_upward_rounded,
                color: AppColors.danger,
                bgColor: AppColors.dangerLight,
                trend: '▼',
                trendColor: AppColors.danger,
              )),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(child: StatCardWidget(
                label: 'Supplier Aktif',
                value: '${_stats['supplier_aktif'] ?? 0}',
                icon: Icons.people_alt_rounded,
                color: AppColors.info,
                bgColor: AppColors.infoLight,
              )),
              const SizedBox(width: 10),
              Expanded(child: StatCardWidget(
                label: 'Stok Rendah',
                value: '${_stats['stok_rendah'] ?? 0}',
                icon: Icons.warning_amber_rounded,
                color: AppColors.warning,
                bgColor: AppColors.warningLight,
              )),
              const SizedBox(width: 10),
              Expanded(child: StatCardWidget(
                label: 'Jenis Barang',
                value: '${_stats['jenis_barang'] ?? 0}',
                icon: Icons.category_rounded,
                color: const Color(0xFF8B5CF6),
                bgColor: const Color(0xFFF5F3FF),
              )),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildChart() {
    if (_chartData.isEmpty) return const SizedBox.shrink();
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 16, 16, 0),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border, width: 0.5),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8, offset: const Offset(0, 2))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Grafik Pergerakan Stok', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.text1)),
          const Text('7 hari terakhir', style: TextStyle(fontSize: 12, color: AppColors.text3)),
          const SizedBox(height: 12),
          Row(
            children: [
              _buildLegend(AppColors.primary, 'Masuk'),
              const SizedBox(width: 16),
              _buildLegend(AppColors.danger, 'Keluar'),
            ],
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: 180,
            child: LineChart(
              LineChartData(
                gridData: FlGridData(
                  show: true,
                  drawVerticalLine: false,
                  getDrawingHorizontalLine: (v) => FlLine(color: AppColors.border, strokeWidth: 0.8),
                ),
                titlesData: FlTitlesData(
                  leftTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      getTitlesWidget: (value, meta) {
                        final idx = value.toInt();
                        if (idx < 0 || idx >= _chartData.length) return const SizedBox.shrink();
                        final date = _chartData[idx]['tanggal'] as DateTime;
                        return Padding(
                          padding: const EdgeInsets.only(top: 4),
                          child: Text(DateFormat('dd/M').format(date),
                              style: const TextStyle(fontSize: 10, color: AppColors.text3)),
                        );
                      },
                    ),
                  ),
                ),
                borderData: FlBorderData(show: false),
                lineBarsData: [
                  _buildLine(_chartData.asMap().entries.map((e) => FlSpot(e.key.toDouble(), (e.value['masuk'] as int).toDouble())).toList(), AppColors.primary),
                  _buildLine(_chartData.asMap().entries.map((e) => FlSpot(e.key.toDouble(), (e.value['keluar'] as int).toDouble())).toList(), AppColors.danger),
                ],
                minY: 0,
              ),
            ),
          ),
        ],
      ),
    );
  }

  LineChartBarData _buildLine(List<FlSpot> spots, Color color) {
    return LineChartBarData(
      spots: spots,
      isCurved: true,
      color: color,
      barWidth: 2.5,
      isStrokeCapRound: true,
      dotData: const FlDotData(show: false),
      belowBarData: BarAreaData(show: true, color: color.withOpacity(0.08)),
    );
  }

  Widget _buildLegend(Color color, String label) {
    return Row(
      children: [
        Container(width: 10, height: 10, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
        const SizedBox(width: 5),
        Text(label, style: const TextStyle(fontSize: 12, color: AppColors.text2)),
      ],
    );
  }

  Widget _buildStokRendahAlert() {
    final rendah = (_stats['stok_rendah'] ?? 0);
    if (rendah == 0) return const SizedBox.shrink();
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.warningLight,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.warning.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          const Icon(Icons.warning_amber_rounded, color: AppColors.warning, size: 20),
          const SizedBox(width: 10),
          Expanded(
            child: Text('$rendah barang memiliki stok rendah atau habis! Segera lakukan pemesanan.',
                style: const TextStyle(fontSize: 13, color: AppColors.warning, fontWeight: FontWeight.w600)),
          ),
        ],
      ),
    );
  }

  Widget _buildAktivitasTerbaru() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 16, 16, 0),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border, width: 0.5),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8, offset: const Offset(0, 2))],
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
            child: Row(
              children: [
                const Text('Aktivitas Terbaru', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.text1)),
                const Spacer(),
                Text('${_aktivitasTerbaru.length} transaksi',
                    style: const TextStyle(fontSize: 12, color: AppColors.text3)),
              ],
            ),
          ),
          const Divider(color: AppColors.divider, height: 1),
          if (_aktivitasTerbaru.isEmpty)
            const Padding(
              padding: EdgeInsets.all(24),
              child: Text('Belum ada aktivitas', style: TextStyle(color: AppColors.text3, fontSize: 14)),
            )
          else
            ListView.separated(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: _aktivitasTerbaru.length,
              separatorBuilder: (_, __) => const Divider(color: AppColors.divider, height: 1, indent: 56),
              itemBuilder: (_, i) {
                final t = _aktivitasTerbaru[i];
                final isMasuk = t.tipe == TipeTransaksi.masuk;
                return ListTile(
                  dense: true,
                  leading: Container(
                    width: 36, height: 36,
                    decoration: BoxDecoration(
                      color: isMasuk ? AppColors.successLight : AppColors.dangerLight,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Center(child: Text(t.barangIkon, style: const TextStyle(fontSize: 16))),
                  ),
                  title: Text(t.barangNama, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.text1)),
                  subtitle: Text(
                    DateFormat('dd MMM yyyy, HH:mm', 'id_ID').format(t.tanggal),
                    style: const TextStyle(fontSize: 11, color: AppColors.text3),
                  ),
                  trailing: Text(
                    '${isMasuk ? '+' : '-'}${t.jumlah}',
                    style: TextStyle(
                      fontSize: 14, fontWeight: FontWeight.w700,
                      color: isMasuk ? AppColors.success : AppColors.danger,
                    ),
                  ),
                );
              },
            ),
        ],
      ),
    );
  }
}
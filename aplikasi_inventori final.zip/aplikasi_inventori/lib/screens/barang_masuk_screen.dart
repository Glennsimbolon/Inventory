// lib/screens/barang_masuk_screen.dart
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../database/database_helper.dart';
import '../models/barang_model.dart';
import '../models/transaksi_model.dart';
import '../theme/app_theme.dart';
import '../services/app_refresh.dart';
import '../providers/inventory_provider.dart';

class BarangMasukScreen extends StatefulWidget {
  const BarangMasukScreen({super.key});
  @override
  State<BarangMasukScreen> createState() => _BarangMasukScreenState();
}

class _BarangMasukScreenState extends State<BarangMasukScreen> {
  final _db = DatabaseHelper();
  List<Barang> _barangList = [];
  bool _isLoading = true;
  final _searchCtrl = TextEditingController();
  List<Barang> _filtered = [];

  @override
  void initState() {
  super.initState();

  _loadData();

  AppRefresh.refreshNotifier.addListener(() {
    _loadData();
  });
}
  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    final data = await _db.getAllBarang();
    if (mounted) {
      setState(() {
        _barangList = data;
        _filtered = data;
        _isLoading = false;
      });
    }
  }

  void _filter(String q) {
    setState(() {
      _filtered = q.isEmpty ? _barangList : _barangList.where((b) => b.nama.toLowerCase().contains(q.toLowerCase())).toList();
    });
  }

  void _showTambahDialog(Barang b) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (_) => _TransaksiForm(
        barang: b,
        tipe: TipeTransaksi.masuk,
        onSave: (jumlah, ket, noRef) async {
          final stokBaru = b.stok + jumlah;
          await _db.updateStokBarang(b.id!, stokBaru);
          await _db.insertTransaksi(Transaksi(
            barangId: b.id!,
            barangNama: b.nama,
            barangIkon: b.ikon,
            tipe: TipeTransaksi.masuk,
            jumlah: jumlah,
            stokSebelum: b.stok,
            stokSesudah: stokBaru,
            keterangan: ket,
            nomorReferensi: noRef,
          ));
          AppRefresh.refreshAll();
          if (mounted) {
            await _loadData();
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: Text('+$jumlah ${b.satuan} ${b.nama} berhasil masuk. Stok: $stokBaru ${b.satuan}'),
              backgroundColor: AppColors.primary,
              behavior: SnackBarBehavior.floating,
            ));
          }
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(
        title: const Text('Barang Masuk'),
        backgroundColor: AppColors.primary,
        actions: [
          IconButton(
            icon: const Icon(Icons.history_rounded, color: Colors.white),
            onPressed: () => _showHistory(),
            tooltip: 'Riwayat',
          ),
        ],
      ),
      body: Column(
        children: [
          // Header info
          Container(
            margin: const EdgeInsets.all(16),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [AppColors.primaryLight, AppColors.primary]),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Row(
              children: [
                const Icon(Icons.arrow_downward_rounded, color: Colors.white, size: 28),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Catat Barang Masuk', style: TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w700)),
                      Text('Pilih barang dan masukkan jumlah yang diterima\n${DateFormat('dd MMMM yyyy', 'id_ID').format(DateTime.now())}',
                          style: const TextStyle(color: Colors.white70, fontSize: 12)),
                    ],
                  ),
                ),
              ],
            ),
          ),
          // Search
          Container(
            margin: const EdgeInsets.fromLTRB(16, 0, 16, 12),
            padding: const EdgeInsets.symmetric(horizontal: 14),
            decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.border)),
            child: Row(
              children: [
                const Icon(Icons.search_rounded, color: AppColors.text3, size: 20),
                const SizedBox(width: 8),
                Expanded(
                  child: TextField(
                    controller: _searchCtrl,
                    onChanged: _filter,
                    decoration: const InputDecoration(hintText: 'Cari barang...', border: InputBorder.none, contentPadding: EdgeInsets.symmetric(vertical: 12)),
                    style: const TextStyle(fontSize: 14),
                  ),
                ),
              ],
            ),
          ),
          // Table header
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 16),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: const BoxDecoration(
              color: AppColors.primary,
              borderRadius: BorderRadius.vertical(top: Radius.circular(12)),
            ),
            child: const Row(
              children: [
                Expanded(flex: 3, child: Text('Nama Barang', style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700))),
                Expanded(flex: 2, child: Text('Stok Saat Ini', style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700), textAlign: TextAlign.center)),
                SizedBox(width: 80, child: Text('Aksi', style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700), textAlign: TextAlign.center)),
              ],
            ),
          ),
         Expanded(
  child: RefreshIndicator(
    color: AppColors.primary,
    onRefresh: _loadData,
    child: _isLoading
                ? const Center(child: CircularProgressIndicator(color: AppColors.primary))
                : _filtered.isEmpty
                    ? const Center(child: Text('Tidak ada barang', style: TextStyle(color: AppColors.text3)))
                    : Container(
                        margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                        decoration: BoxDecoration(
                          color: AppColors.surface,
                          borderRadius: const BorderRadius.vertical(bottom: Radius.circular(12)),
                          border: Border.all(color: AppColors.border, width: 0.5),
                          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8, offset: const Offset(0, 2))],
                        ),
                        child: ListView.separated(
                          itemCount: _filtered.length,
                          separatorBuilder: (_, __) => const Divider(color: AppColors.divider, height: 1),
                          itemBuilder: (_, i) => _buildRow(_filtered[i]),
                        ),
                      ),
          ),
         ),
        ],
      ),
    );
  }

  Widget _buildRow(Barang b) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      child: Row(
        children: [
          Container(
            width: 34, height: 34,
            decoration: BoxDecoration(color: AppColors.primaryLighter, borderRadius: BorderRadius.circular(8)),
            child: Center(child: Text(b.ikon, style: const TextStyle(fontSize: 16))),
          ),
          const SizedBox(width: 10),
          Expanded(
            flex: 3,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(b.nama, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.text1)),
                Text('${b.jenis} • ${b.satuan}', style: const TextStyle(fontSize: 11, color: AppColors.text3)),
              ],
            ),
          ),
          Expanded(
            flex: 2,
            child: Column(
              children: [
                Text('${b.stok}', style: TextStyle(
                  fontSize: 16, fontWeight: FontWeight.w800,
                  color: b.isStokRendah ? AppColors.warning : AppColors.primary,
                ), textAlign: TextAlign.center),
                Text(b.satuan, style: const TextStyle(fontSize: 10, color: AppColors.text3), textAlign: TextAlign.center),
              ],
            ),
          ),
          SizedBox(
            width: 80,
            child: ElevatedButton(
              onPressed: () => _showTambahDialog(b),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primary,
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                minimumSize: Size.zero,
              ),
              child: const Text('+ Masuk', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700)),
            ),
          ),
        ],
      ),
    );
  }

  void _showHistory() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      isScrollControlled: true,
      builder: (_) => DraggableScrollableSheet(
        initialChildSize: 0.7,
        maxChildSize: 0.92,
        minChildSize: 0.4,
        expand: false,
        builder: (_, ctrl) => _RiwayatTransaksi(tipe: TipeTransaksi.masuk, scrollController: ctrl),
      ),
    );
  }
}

// ==================== TRANSAKSI FORM ====================
class _TransaksiForm extends StatefulWidget {
  final Barang barang;
  final TipeTransaksi tipe;
  final Function(int jumlah, String? keterangan, String? noRef) onSave;
  const _TransaksiForm({required this.barang, required this.tipe, required this.onSave});
  @override
  State<_TransaksiForm> createState() => _TransaksiFormState();
}

class _TransaksiFormState extends State<_TransaksiForm> {
  final _formKey = GlobalKey<FormState>();
  final _jumlahCtrl = TextEditingController(text: '1');
  final _ketCtrl = TextEditingController();
  final _noRefCtrl = TextEditingController();
  int _jumlah = 1;

  @override
  void dispose() {
    _jumlahCtrl.dispose(); _ketCtrl.dispose(); _noRefCtrl.dispose();
    super.dispose();
  }

  void _save() {
    if (!_formKey.currentState!.validate()) return;
    final j = int.tryParse(_jumlahCtrl.text) ?? 1;
    if (widget.tipe == TipeTransaksi.keluar && j > widget.barang.stok) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Jumlah keluar melebihi stok tersedia!'),
        backgroundColor: AppColors.danger,
        behavior: SnackBarBehavior.floating,
      ));
      return;
    }
    Navigator.pop(context);
    widget.onSave(j, _ketCtrl.text.trim().isEmpty ? null : _ketCtrl.text.trim(), _noRefCtrl.text.trim().isEmpty ? null : _noRefCtrl.text.trim());
  }

  @override
  Widget build(BuildContext context) {
    final isMasuk = widget.tipe == TipeTransaksi.masuk;
    final color = isMasuk ? AppColors.primary : AppColors.danger;
    final bgColor = isMasuk ? AppColors.primaryLighter : AppColors.dangerLight;
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(child: Container(width: 36, height: 4, decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(2)))),
                const SizedBox(height: 20),
                Row(
                  children: [
                    Container(
                      width: 44, height: 44,
                      decoration: BoxDecoration(color: bgColor, borderRadius: BorderRadius.circular(12)),
                      child: Center(child: Text(widget.barang.ikon, style: const TextStyle(fontSize: 22))),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(widget.barang.nama, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: AppColors.text1)),
                          Text('Stok saat ini: ${widget.barang.stok} ${widget.barang.satuan}',
                              style: TextStyle(fontSize: 12, color: color, fontWeight: FontWeight.w600)),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(color: bgColor, borderRadius: BorderRadius.circular(12)),
                  child: Row(
                    children: [
                      Icon(isMasuk ? Icons.arrow_downward_rounded : Icons.arrow_upward_rounded, color: color, size: 20),
                      const SizedBox(width: 8),
                      Text('${isMasuk ? 'Masuk' : 'Keluar'} ke/dari Gudang', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: color)),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                const Text('Jumlah *', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.text2)),
                const SizedBox(height: 8),
                Row(
                  children: [
                    _buildQtyBtn('-', () { if (_jumlah > 1) setState(() { _jumlah--; _jumlahCtrl.text = '$_jumlah'; }); }),
                    const SizedBox(width: 12),
                    Expanded(
                      child: TextFormField(
                        controller: _jumlahCtrl,
                        keyboardType: TextInputType.number,
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: color),
                        onChanged: (v) => _jumlah = int.tryParse(v) ?? 1,
                        validator: (v) {
                          final n = int.tryParse(v ?? '');
                          if (n == null || n <= 0) return 'Minimal 1';
                          return null;
                        },
                        decoration: InputDecoration(
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: color, width: 2)),
                          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: color, width: 2)),
                          fillColor: bgColor,
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    _buildQtyBtn('+', () => setState(() { _jumlah++; _jumlahCtrl.text = '$_jumlah'; })),
                  ],
                ),
                // Quick add buttons
                const SizedBox(height: 10),
                Wrap(
                  spacing: 8, runSpacing: 8,
                  children: [5, 10, 25, 50, 100].map((n) => GestureDetector(
                    onTap: () => setState(() { _jumlah = n; _jumlahCtrl.text = '$n'; }),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: _jumlah == n ? color : AppColors.bg,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: _jumlah == n ? color : AppColors.border),
                      ),
                      child: Text('+$n', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: _jumlah == n ? Colors.white : AppColors.text2)),
                    ),
                  )).toList(),
                ),
                const SizedBox(height: 14),
                const Text('No. Referensi / PO', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.text2)),
                const SizedBox(height: 6),
                TextFormField(controller: _noRefCtrl, decoration: const InputDecoration(hintText: 'Opsional: nomor PO, surat jalan...')),
                const SizedBox(height: 12),
                const Text('Keterangan', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.text2)),
                const SizedBox(height: 6),
                TextFormField(controller: _ketCtrl, maxLines: 2, decoration: const InputDecoration(hintText: 'Catatan tambahan (opsional)...')),
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _save,
                    style: ElevatedButton.styleFrom(backgroundColor: color),
                    child: Text('Simpan ${isMasuk ? 'Barang Masuk' : 'Barang Keluar'}'),
                  ),
                ),
                const SizedBox(height: 8),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildQtyBtn(String label, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 44, height: 44,
        decoration: BoxDecoration(
          color: AppColors.bg,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: AppColors.border),
        ),
        child: Center(child: Text(label, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700, color: AppColors.text1))),
      ),
    );
  }
}

// ==================== RIWAYAT TRANSAKSI ====================
class _RiwayatTransaksi extends StatefulWidget {
  final TipeTransaksi tipe;
  final ScrollController scrollController;
  const _RiwayatTransaksi({required this.tipe, required this.scrollController});
  @override
  State<_RiwayatTransaksi> createState() => _RiwayatTransaksiState();
}

class _RiwayatTransaksiState extends State<_RiwayatTransaksi> {
  final _db = DatabaseHelper();
  List<Transaksi> _list = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final data = await _db.getTransaksiByTipe(widget.tipe);
    if (mounted) setState(() { _list = data; _isLoading = false; });
  }

  @override
  Widget build(BuildContext context) {
    final isMasuk = widget.tipe == TipeTransaksi.masuk;
    final color = isMasuk ? AppColors.primary : AppColors.danger;
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(20),
          child: Row(
            children: [
              Container(width: 36, height: 4, decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(2))),
              const Spacer(),
              Text('Riwayat ${isMasuk ? 'Barang Masuk' : 'Barang Keluar'}',
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppColors.text1)),
              const Spacer(),
              Text('${_list.length} data', style: const TextStyle(fontSize: 12, color: AppColors.text3)),
            ],
          ),
        ),
        const Divider(height: 1),
        Expanded(
          child: _isLoading
              ? const Center(child: CircularProgressIndicator(color: AppColors.primary))
              : _list.isEmpty
                  ? const Center(child: Text('Belum ada riwayat', style: TextStyle(color: AppColors.text3)))
                  : ListView.separated(
                      controller: widget.scrollController,
                      itemCount: _list.length,
                      separatorBuilder: (_, __) => const Divider(indent: 64, height: 1, color: AppColors.divider),
                      itemBuilder: (_, i) {
                        final t = _list[i];
                        return ListTile(
                          leading: Container(
                            width: 40, height: 40,
                            decoration: BoxDecoration(
                              color: isMasuk ? AppColors.primaryLighter : AppColors.dangerLight,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Center(child: Text(t.barangIkon, style: const TextStyle(fontSize: 18))),
                          ),
                          title: Text(t.barangNama, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.text1)),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(DateFormat('dd MMM yyyy, HH:mm', 'id_ID').format(t.tanggal),
                                  style: const TextStyle(fontSize: 11, color: AppColors.text3)),
                              if (t.keterangan != null && t.keterangan!.isNotEmpty)
                                Text(t.keterangan!, style: const TextStyle(fontSize: 11, color: AppColors.text3)),
                            ],
                          ),
                          trailing: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text('${isMasuk ? '+' : '-'}${t.jumlah}',
                                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: color)),
                              Text('${t.stokSebelum} → ${t.stokSesudah}',
                                  style: const TextStyle(fontSize: 10, color: AppColors.text3)),
                            ],
                          ),
                        );
                      },
                    ),
        ),
      ],
    );
  }
}
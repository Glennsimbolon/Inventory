package com.example.aplikasi_inventori

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()

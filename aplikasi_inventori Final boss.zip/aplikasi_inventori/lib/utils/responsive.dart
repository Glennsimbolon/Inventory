// lib/utils/responsive.dart
import 'package:flutter/material.dart';

class Responsive {
  static double screenWidth(BuildContext context) =>
      MediaQuery.of(context).size.width;

  static double screenHeight(BuildContext context) =>
      MediaQuery.of(context).size.height;

  static double width(BuildContext context, double percentage) =>
      screenWidth(context) * percentage;

  static double height(BuildContext context, double percentage) =>
      screenHeight(context) * percentage;

  static double fontSize(BuildContext context, double size,
      {double maxScale = 1.5, double minScale = 0.8}) {
    final scale = screenWidth(context) / 375;
    final scaled = size * scale;
    return scaled.clamp(size * minScale, size * maxScale);
  }

  static EdgeInsets padding({
    required BuildContext context,
    double all = 0,
    double horizontal = 0,
    double vertical = 0,
    double left = 0,
    double top = 0,
    double right = 0,
    double bottom = 0,
  }) {
    final w = screenWidth(context);
    final h = screenHeight(context);
    return EdgeInsets.only(
      left: left == 0 ? (horizontal == 0 ? all * w : horizontal * w) : left * w,
      top: top == 0 ? (vertical == 0 ? all * h : vertical * h) : top * h,
      right: right == 0 ? (horizontal == 0 ? all * w : horizontal * w) : right * w,
      bottom: bottom == 0 ? (vertical == 0 ? all * h : vertical * h) : bottom * h,
    );
  }

  static EdgeInsets margin({
    required BuildContext context,
    double all = 0,
    double horizontal = 0,
    double vertical = 0,
    double left = 0,
    double top = 0,
    double right = 0,
    double bottom = 0,
  }) {
    return padding(
      context: context,
      all: all,
      horizontal: horizontal,
      vertical: vertical,
      left: left,
      top: top,
      right: right,
      bottom: bottom,
    );
  }

  static bool isMobile(BuildContext context) => screenWidth(context) < 600;
  static bool isTablet(BuildContext context) =>
      screenWidth(context) >= 600 && screenWidth(context) < 1200;
  static bool isDesktop(BuildContext context) => screenWidth(context) >= 1200;
}

class ResponsiveLayout extends StatelessWidget {
  final Widget mobile;
  final Widget tablet;
  final Widget desktop;

  const ResponsiveLayout({
    super.key,
    required this.mobile,
    required this.tablet,
    required this.desktop,
  });

  @override
  Widget build(BuildContext context) {
    if (Responsive.isDesktop(context)) return desktop;
    if (Responsive.isTablet(context)) return tablet;
    return mobile;
  }
}

extension ResponsivePadding on Widget {
  Widget paddingAll(BuildContext context, double all) {
    return Padding(
      padding: Responsive.padding(context: context, all: all),
      child: this,
    );
  }

  Widget paddingHorizontal(BuildContext context, double horizontal) {
    return Padding(
      padding: Responsive.padding(context: context, horizontal: horizontal),
      child: this,
    );
  }

  Widget paddingVertical(BuildContext context, double vertical) {
    return Padding(
      padding: Responsive.padding(context: context, vertical: vertical),
      child: this,
    );
  }
}

class ResponsiveGridView extends StatelessWidget {
  final int itemCount;
  final Widget Function(BuildContext, int) itemBuilder;
  final double maxItemWidth;
  final double childAspectRatio;
  final double spacing;
  final double runSpacing;
  final EdgeInsetsGeometry padding;

  const ResponsiveGridView({
    super.key,
    required this.itemCount,
    required this.itemBuilder,
    this.maxItemWidth = 200,
    this.childAspectRatio = 1.0,
    this.spacing = 8,
    this.runSpacing = 8,
    this.padding = const EdgeInsets.all(8),
  });

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final crossAxisCount = (screenWidth / maxItemWidth).floor().clamp(1, 6);

    return GridView.builder(
      padding: padding,
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: crossAxisCount,
        childAspectRatio: childAspectRatio,
        crossAxisSpacing: spacing,
        mainAxisSpacing: runSpacing,
      ),
      itemCount: itemCount,
      itemBuilder: itemBuilder,
    );
  }
}
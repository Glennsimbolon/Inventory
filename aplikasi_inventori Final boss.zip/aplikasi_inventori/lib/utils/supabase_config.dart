
//
// ╔══════════════════════════════════════════════════════════════╗
// ║  GANTI NILAI INI DENGAN CREDENTIALS SUPABASE KAMU           ║
// ║                                                              ║
// ║  Cara mendapatkan:                                           ║
// ║  1. Buka https://supabase.com → Login → Buka project kamu   ║
// ║  2. Klik Settings → API                                      ║
// ║  3. Copy "Project URL" dan "anon public" key                 ║
// ╚══════════════════════════════════════════════════════════════╝
 
class SupabaseConfig {
  /// URL project Supabase kamu
  /// Contoh: https://xyzabcdefgh.supabase.co
  static const String supabaseUrl = 'https://xwwokmsskyqpgeceqwwe.supabase.co';
 
  /// Anon / public key dari Supabase
  static const String supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inh3d29rbXNza3lxcGdlY2Vxd3dlIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzkzNTU0MjYsImV4cCI6MjA5NDkzMTQyNn0.iJjusCqzy9pGZQnfowX4Vqw0aWQRjEjBh8GtxPRKEDQ';
 
  /// Nama bucket untuk foto barang di Supabase Storage
  static const String storageBucket = 'barang-foto';
 
  /// Nama tabel di Supabase PostgreSQL
  static const String tableBarang     = 'barang';
  static const String tableSuppliers  = 'suppliers';
  static const String tableTransaksi  = 'transaksi';
  static const String tableProfiles   = 'profiles';
}
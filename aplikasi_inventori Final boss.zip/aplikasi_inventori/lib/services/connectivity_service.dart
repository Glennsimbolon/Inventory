// lib/services/connectivity_service.dart
import 'dart:async';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
 
class ConnectivityService {
  static final ConnectivityService _instance = ConnectivityService._internal();
  factory ConnectivityService() => _instance;
  ConnectivityService._internal();
 
  final Connectivity _connectivity = Connectivity();
  final ValueNotifier<bool> isOnline = ValueNotifier<bool>(false);
 
  StreamSubscription<List<ConnectivityResult>>? _subscription;
 
  /// Inisialisasi listener koneksi
  Future<void> init() async {
    final result = await _connectivity.checkConnectivity();
    isOnline.value = _isConnected(result);
 
    _subscription = _connectivity.onConnectivityChanged.listen((results) {
      isOnline.value = _isConnected(results);
    });
  }
 
  bool _isConnected(List<ConnectivityResult> results) {
    return results.any((r) =>
        r == ConnectivityResult.mobile ||
        r == ConnectivityResult.wifi ||
        r == ConnectivityResult.ethernet);
  }
 
  void dispose() {
    _subscription?.cancel();
    isOnline.dispose();
  }
}
 
import 'package:flutter/material.dart';

class AppRefresh {
  static ValueNotifier<int> refreshNotifier = ValueNotifier(0);

  static void refreshAll() {
    refreshNotifier.value++;
  }
}
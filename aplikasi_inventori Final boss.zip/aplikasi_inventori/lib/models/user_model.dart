// lib/models/user_model.dart
import 'dart:convert';
import 'package:crypto/crypto.dart';

class User {
  final int? id;
  final String username;
  final String passwordHash;
  final String namaLengkap;
  final String role; // 'admin' | 'operator' | 'viewer'
  final String? email;
  final String? fotoProfil;
  final bool isActive;
  final DateTime? lastLogin;
  final DateTime createdAt;

  User({
    this.id,
    required this.username,
    required this.passwordHash,
    required this.namaLengkap,
    this.role = 'operator',
    this.email,
    this.fotoProfil,
    this.isActive = true,
    this.lastLogin,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  /// Hash password menggunakan SHA-256
  static String hashPassword(String password) {
    final bytes = utf8.encode(password);
    return sha256.convert(bytes).toString();
  }

  /// Verifikasi password
  bool verifyPassword(String password) {
    return passwordHash == hashPassword(password);
  }

  factory User.fromMap(Map<String, dynamic> map) {
    return User(
      id: map['id'] as int?,
      username: map['username'] as String,
      passwordHash: map['password_hash'] as String,
      namaLengkap: map['nama_lengkap'] as String,
      role: map['role'] as String? ?? 'operator',
      email: map['email'] as String?,
      fotoProfil: map['foto_profil'] as String?,
      isActive: (map['is_active'] as int? ?? 1) == 1,
      lastLogin: map['last_login'] != null
          ? DateTime.tryParse(map['last_login'] as String)
          : null,
      createdAt: DateTime.tryParse(map['created_at'] as String? ?? '') ??
          DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      if (id != null) 'id': id,
      'username': username,
      'password_hash': passwordHash,
      'nama_lengkap': namaLengkap,
      'role': role,
      'email': email,
      'foto_profil': fotoProfil,
      'is_active': isActive ? 1 : 0,
      'last_login': lastLogin?.toIso8601String(),
      'created_at': createdAt.toIso8601String(),
    };
  }

  User copyWith({
    int? id,
    String? username,
    String? passwordHash,
    String? namaLengkap,
    String? role,
    String? email,
    String? fotoProfil,
    bool? isActive,
    DateTime? lastLogin,
  }) {
    return User(
      id: id ?? this.id,
      username: username ?? this.username,
      passwordHash: passwordHash ?? this.passwordHash,
      namaLengkap: namaLengkap ?? this.namaLengkap,
      role: role ?? this.role,
      email: email ?? this.email,
      fotoProfil: fotoProfil ?? this.fotoProfil,
      isActive: isActive ?? this.isActive,
      lastLogin: lastLogin ?? this.lastLogin,
      createdAt: createdAt,
    );
  }

  /// Label role yang ramah tampilan
  String get roleLabel {
    switch (role) {
      case 'admin':
        return 'Administrator';
      case 'operator':
        return 'Operator Gudang';
      case 'viewer':
        return 'Viewer (Read Only)';
      default:
        return role;
    }
  }

  /// Cek apakah user boleh mengedit data
  bool get canEdit => role == 'admin' || role == 'operator';

  /// Cek apakah user boleh akses manajemen user
  bool get isAdmin => role == 'admin';
}
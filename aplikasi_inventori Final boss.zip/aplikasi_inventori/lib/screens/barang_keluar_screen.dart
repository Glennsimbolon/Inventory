// lib/screens/barang_keluar_screen.dart
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/barang_model.dart';
import '../models/transaksi_model.dart';
import '../theme/app_theme.dart';
import '../widgets/riwayat_transaksi.dart';

class BarangKeluarScreen extends StatefulWidget {
  const BarangKeluarScreen({super.key});

  @override
  State<BarangKeluarScreen> createState() => _BarangKeluarScreenState();
}

class _BarangKeluarScreenState extends State<BarangKeluarScreen> {
  final _supabase = Supabase.instance.client;
  List<Barang> _barangList = [];
  List<Barang> _filtered = [];
  bool _isLoading = true;
  final _searchCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadBarang();
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadBarang() async {
    if (!mounted) return;
    setState(() => _isLoading = true);
    try {
      final response = await _supabase.from('barang').select('*');
      final List<Barang> data = (response as List)
          .map((json) => Barang.fromMap(json))
          .toList();
      if (mounted) {
        setState(() {
          _barangList = data;
          _filtered = data;
          _isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() => _isLoading = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal memuat data: $e'), backgroundColor: AppColors.danger),
        );
      }
    }
  }

  void _filter(String q) {
    if (!mounted) return;
    setState(() {
      _filtered = q.isEmpty
          ? _barangList
          : _barangList.where((b) => b.nama.toLowerCase().contains(q.toLowerCase())).toList();
    });
  }

  void _showKeluarDialog(Barang b) {
    if (b.stok <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('${b.nama} stok sudah habis!'),
        backgroundColor: AppColors.danger,
        behavior: SnackBarBehavior.floating,
      ));
      return;
    }

    final screenContext = context;
    final jumlahCtrl = TextEditingController(text: '1');
    final ketCtrl = TextEditingController();
    final noRefCtrl = TextEditingController();
    int jumlah = 1;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (_) {
        return StatefulBuilder(
          builder: (context, setStateBottom) {
            return Padding(
              padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(child: Container(width: 36, height: 4, decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(2)))),
                    const SizedBox(height: 20),
                    Row(
                      children: [
                        Container(
                          width: 44, height: 44,
                          decoration: BoxDecoration(color: AppColors.dangerLight, borderRadius: BorderRadius.circular(12)),
                          child: Center(child: Text(b.ikon, style: const TextStyle(fontSize: 22))),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(b.nama, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
                              Text('Stok saat ini: ${b.stok} ${b.satuan}', style: const TextStyle(fontSize: 12, color: AppColors.danger)),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),
                    Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(color: AppColors.dangerLight, borderRadius: BorderRadius.circular(12)),
                      child: Row(
                        children: [
                          const Icon(Icons.arrow_upward_rounded, color: AppColors.danger),
                          const SizedBox(width: 8),
                          const Text('Keluar dari Gudang', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.danger)),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    const Text('Jumlah *', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        _buildQtyBtn('-', () {
                          if (jumlah > 1) {
                            jumlah--;
                            jumlahCtrl.text = jumlah.toString();
                            setStateBottom(() {});
                          }
                        }),
                        const SizedBox(width: 12),
                        Expanded(
                          child: TextFormField(
                            controller: jumlahCtrl,
                            keyboardType: TextInputType.number,
                            textAlign: TextAlign.center,
                            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: AppColors.danger),
                            onChanged: (v) {
                              int newJumlah = int.tryParse(v) ?? 1;
                              if (newJumlah > b.stok) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(content: Text('Maksimal keluar: ${b.stok} ${b.satuan}'), backgroundColor: AppColors.warning),
                                );
                                newJumlah = b.stok;
                                jumlahCtrl.text = newJumlah.toString();
                              }
                              jumlah = newJumlah;
                              setStateBottom(() {});
                            },
                            decoration: InputDecoration(
                              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: AppColors.danger)),
                              focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: AppColors.danger)),
                              fillColor: AppColors.dangerLight,
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        _buildQtyBtn('+', () {
                          if (jumlah < b.stok) {
                            jumlah++;
                            jumlahCtrl.text = jumlah.toString();
                            setStateBottom(() {});
                          }
                        }),
                      ],
                    ),
                    if (jumlah > b.stok) ...[
                      const SizedBox(height: 8),
                      Text('⚠️ Jumlah melebihi stok! Maksimal ${b.stok} ${b.satuan}',
                          style: TextStyle(fontSize: 11, color: AppColors.danger)),
                    ],
                    const SizedBox(height: 10),
                    Wrap(
                      spacing: 8,
                      children: [1, 2, 5, 10, 25].where((n) => n <= b.stok).map((n) => GestureDetector(
                        onTap: () {
                          jumlah = n;
                          jumlahCtrl.text = n.toString();
                          setStateBottom(() {});
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: jumlah == n ? AppColors.danger : AppColors.bg,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: jumlah == n ? AppColors.danger : AppColors.border),
                          ),
                          child: Text('-$n', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: jumlah == n ? Colors.white : AppColors.text2)),
                        ),
                      )).toList(),
                    ),
                    const SizedBox(height: 14),
                    const Text('No. Referensi / PO', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                    const SizedBox(height: 6),
                    TextFormField(controller: noRefCtrl, decoration: const InputDecoration(hintText: 'Opsional: nomor PO, surat jalan...')),
                    const SizedBox(height: 12),
                    const Text('Keterangan', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                    const SizedBox(height: 6),
                    TextFormField(controller: ketCtrl, maxLines: 2, decoration: const InputDecoration(hintText: 'Catatan tambahan (opsional)...')),
                    const SizedBox(height: 20),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: () async {
                          final j = int.tryParse(jumlahCtrl.text) ?? 1;
                          if (j <= 0) {
                            if (screenContext.mounted) {
                              ScaffoldMessenger.of(screenContext).showSnackBar(
                                SnackBar(content: Text('Jumlah harus lebih dari 0'), backgroundColor: AppColors.warning),
                              );
                            }
                            return;
                          }
                          if (j > b.stok) {
                            if (screenContext.mounted) {
                              ScaffoldMessenger.of(screenContext).showSnackBar(
                                SnackBar(content: Text('Stok tidak mencukupi! Sisa stok: ${b.stok} ${b.satuan}'), backgroundColor: AppColors.danger),
                              );
                            }
                            return;
                          }
                          if (mounted) Navigator.pop(context);
                          try {
                            final stokBaru = b.stok - j;
                            await _supabase.from('barang').update({'stok': stokBaru}).eq('id', b.id!);
                            await _supabase.from('transaksi').insert({
  'barang_id': b.id,
  'barang_nama': b.nama,
  'barang_ikon': b.ikon,
  'tipe': 'keluar',
  'jumlah': j,
  'stok_sebelum': b.stok,
  'stok_sesudah': stokBaru,
  'keterangan': ketCtrl.text.trim().isEmpty ? null : ketCtrl.text.trim(),
  'nomor_referensi': noRefCtrl.text.trim().isEmpty ? null : noRefCtrl.text.trim(),
  'tanggal': DateTime.now().toIso8601String(),
  'created_at': DateTime.now().toIso8601String(),
});
                            await _loadBarang();
                            if (screenContext.mounted) {
                              ScaffoldMessenger.of(screenContext).showSnackBar(
                                SnackBar(content: Text('-$j ${b.satuan} ${b.nama} berhasil keluar. Sisa: $stokBaru ${b.satuan}'), backgroundColor: AppColors.danger),
                              );
                            }
                          } catch (e) {
                            if (screenContext.mounted) {
                              ScaffoldMessenger.of(screenContext).showSnackBar(
                                SnackBar(content: Text('Gagal menyimpan: $e'), backgroundColor: AppColors.danger),
                              );
                            }
                          }
                        },
                        style: ElevatedButton.styleFrom(backgroundColor: AppColors.danger),
                        child: const Text('Simpan Barang Keluar'),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildQtyBtn(String label, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 44, height: 44,
        decoration: BoxDecoration(
          color: AppColors.bg,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: AppColors.border),
        ),
        child: Center(child: Text(label, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700))),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(
        title: const Text('Barang Keluar'),
        backgroundColor: AppColors.danger,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded, color: Colors.white),
            onPressed: _loadBarang,
            tooltip: 'Refresh',
          ),
          IconButton(
            icon: const Icon(Icons.history_rounded, color: Colors.white),
            onPressed: () => _showHistory(),
            tooltip: 'Riwayat',
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _loadBarang,
        color: AppColors.danger,
        child: Column(
          children: [
            Container(
              margin: const EdgeInsets.all(16),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [AppColors.danger, Color(0xFFB91C1C)]),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Row(
                children: [
                  const Icon(Icons.arrow_upward_rounded, color: Colors.white, size: 28),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Catat Barang Keluar', style: TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w700)),
                        Text('Pilih barang yang akan dikeluarkan dari gudang\n${DateFormat('dd MMMM yyyy', 'id_ID').format(DateTime.now())}',
                            style: const TextStyle(color: Colors.white70, fontSize: 12)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              margin: const EdgeInsets.fromLTRB(16, 0, 16, 12),
              padding: const EdgeInsets.symmetric(horizontal: 14),
              decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.border)),
              child: Row(
                children: [
                  const Icon(Icons.search_rounded, color: AppColors.text3, size: 20),
                  const SizedBox(width: 8),
                  Expanded(
                    child: TextField(
                      controller: _searchCtrl,
                      onChanged: _filter,
                      decoration: const InputDecoration(hintText: 'Cari barang...', border: InputBorder.none, contentPadding: EdgeInsets.symmetric(vertical: 12)),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 16),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: const BoxDecoration(
                color: AppColors.danger,
                borderRadius: BorderRadius.vertical(top: Radius.circular(12)),
              ),
              child: const Row(
                children: [
                  Expanded(flex: 3, child: Text('Nama Barang', style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700))),
                  Expanded(flex: 2, child: Text('Stok Tersedia', style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700), textAlign: TextAlign.center)),
                  SizedBox(width: 80, child: Text('Aksi', style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700), textAlign: TextAlign.center)),
                ],
              ),
            ),
            Expanded(
              child: _isLoading
                  ? const Center(child: CircularProgressIndicator(color: AppColors.danger))
                  : _filtered.isEmpty
                      ? const Center(child: Text('Tidak ada barang', style: TextStyle(color: AppColors.text3)))
                      : Container(
                          margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                          decoration: BoxDecoration(
                            color: AppColors.surface,
                            borderRadius: const BorderRadius.vertical(bottom: Radius.circular(12)),
                            border: Border.all(color: AppColors.border),
                          ),
                          child: ListView.separated(
                            itemCount: _filtered.length,
                            separatorBuilder: (_, __) => const Divider(color: AppColors.divider, height: 1),
                            itemBuilder: (_, i) => _buildRow(_filtered[i]),
                          ),
                        ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRow(Barang b) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      child: Row(
        children: [
          Container(
            width: 34, height: 34,
            decoration: BoxDecoration(
              color: b.stok <= 0 ? AppColors.dangerLight : AppColors.primaryLighter,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Center(child: Text(b.ikon, style: const TextStyle(fontSize: 16))),
          ),
          const SizedBox(width: 10),
          Expanded(
            flex: 3,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(b.nama, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                Text('${b.jenis} • ${b.satuan}', style: const TextStyle(fontSize: 11, color: AppColors.text3)),
              ],
            ),
          ),
          Expanded(
            flex: 2,
            child: Column(
              children: [
                Text('${b.stok}', style: TextStyle(
                  fontSize: 16, fontWeight: FontWeight.w800,
                  color: b.stok <= 0 ? AppColors.danger : (b.isStokRendah ? AppColors.warning : AppColors.primary),
                ), textAlign: TextAlign.center),
                Text(b.satuan, style: const TextStyle(fontSize: 10, color: AppColors.text3), textAlign: TextAlign.center),
              ],
            ),
          ),
          SizedBox(
            width: 80,
            child: ElevatedButton(
              onPressed: b.stok <= 0 ? null : () => _showKeluarDialog(b),
              style: ElevatedButton.styleFrom(
                backgroundColor: b.stok <= 0 ? AppColors.text3 : AppColors.danger,
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
              ),
              child: Text(b.stok <= 0 ? 'Habis' : '- Keluar', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700)),
            ),
          ),
        ],
      ),
    );
  }

  void _showHistory() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (_) => DraggableScrollableSheet(
        initialChildSize: 0.7,
        maxChildSize: 0.92,
        minChildSize: 0.4,
        expand: false,
        builder: (_, ctrl) => RiwayatTransaksi(tipe: TipeTransaksi.keluar, scrollController: ctrl),
      ),
    );
  }
}
// lib/screens/supplier_screen.dart
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/supplier_model.dart';
import '../theme/app_theme.dart';

class SupplierScreen extends StatefulWidget {
  const SupplierScreen({super.key});

  @override
  State<SupplierScreen> createState() => _SupplierScreenState();
}

class _SupplierScreenState extends State<SupplierScreen> {
  final _supabase = Supabase.instance.client;
  List<Supplier> _supplierList = [];
  List<Supplier> _filtered = [];
  bool _isLoading = true;
  final _searchCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    try {
      final response = await _supabase.from('suppliers').select();
      final List<Supplier> data = (response as List)
          .map((e) => Supplier.fromMap(e))
          .toList();
      if (mounted) {
        setState(() {
          _supplierList = data;
          _filtered = data;
          _isLoading = false;
        });
      }
    } catch (e) {
      print('Error load supplier: $e');
      if (mounted) {
        setState(() => _isLoading = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal memuat data: $e'), backgroundColor: AppColors.danger),
        );
      }
    }
  }

  void _filter(String q) {
    setState(() {
      _filtered = q.isEmpty
          ? _supplierList
          : _supplierList.where((s) => s.nama.toLowerCase().contains(q.toLowerCase())).toList();
    });
  }

  void _showAddForm([Supplier? existing]) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (_) => _SupplierForm(
        supplier: existing,
        onSave: (s) async {
          try {
            if (existing == null) {
              final Map<String, dynamic> data = s.toMap();
              data.remove('id');
              await _supabase.from('suppliers').insert(data);
            } else {
              await _supabase.from('suppliers').update(s.toMap()).eq('id', s.id!);
            }
            await _loadData();
            if (mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(existing == null ? 'Supplier berhasil ditambahkan' : 'Supplier berhasil diperbarui'),
                  backgroundColor: AppColors.primary,
                  behavior: SnackBarBehavior.floating,
                ),
              );
            }
          } catch (e) {
            print('Error save supplier: $e');
            if (mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Gagal menyimpan: $e'), backgroundColor: AppColors.danger),
              );
            }
          }
        },
      ),
    );
  }

  void _deleteSupplier(Supplier s) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Hapus Supplier'),
        content: Text('Yakin ingin menghapus ${s.nama}?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.danger),
            child: const Text('Hapus'),
          ),
        ],
      ),
    );
    if (confirm == true) {
      try {
        await _supabase.from('suppliers').delete().eq('id', s.id!);
        await _loadData();
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('${s.nama} berhasil dihapus'), backgroundColor: AppColors.danger),
          );
        }
      } catch (e) {
        print('Error delete supplier: $e');
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Gagal menghapus: $e'), backgroundColor: AppColors.danger),
          );
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(
        title: const Text('Daftar Supplier'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded, color: Colors.white),
            onPressed: _loadData,
            tooltip: 'Refresh',
          ),
          Padding(
            padding: const EdgeInsets.only(right: 8),
            child: TextButton.icon(
              onPressed: () => _showAddForm(),
              icon: const Icon(Icons.add_rounded, color: Colors.white, size: 18),
              label: const Text('Tambah', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
            ),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _loadData,
        color: AppColors.primary,
        child: Column(
          children: [
            // Search bar
            Container(
              margin: const EdgeInsets.fromLTRB(16, 12, 16, 8),
              padding: const EdgeInsets.symmetric(horizontal: 14),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColors.border),
              ),
              child: Row(
                children: [
                  const Icon(Icons.search_rounded, color: AppColors.text3, size: 20),
                  const SizedBox(width: 8),
                  Expanded(
                    child: TextField(
                      controller: _searchCtrl,
                      onChanged: _filter,
                      decoration: const InputDecoration(
                        hintText: 'Cari nama supplier...',
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.symmetric(vertical: 12),
                      ),
                      style: const TextStyle(fontSize: 14),
                    ),
                  ),
                ],
              ),
            ),
            // Info bar
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              child: Row(
                children: [
                  Text('${_filtered.length} supplier', style: const TextStyle(fontSize: 12, color: AppColors.text3)),
                ],
              ),
            ),
            Expanded(
              child: _isLoading
                  ? const Center(child: CircularProgressIndicator(color: AppColors.primary))
                  : _filtered.isEmpty
                      ? _buildEmpty()
                      : ListView.separated(
                          padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
                          itemCount: _filtered.length,
                          separatorBuilder: (_, __) => const Divider(color: AppColors.divider, height: 1),
                          itemBuilder: (_, i) => _buildListTile(_filtered[i]),
                        ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildListTile(Supplier s) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      leading: CircleAvatar(
        backgroundColor: AppColors.primaryLighter,
        child: Text(s.nama.isNotEmpty ? s.nama[0].toUpperCase() : '?',
            style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.bold)),
      ),
      title: Text(s.nama, style: const TextStyle(fontWeight: FontWeight.w600)),
      subtitle: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (s.kontak.isNotEmpty) Text(s.kontak, style: const TextStyle(fontSize: 12)),
          if (s.alamat.isNotEmpty) Text(s.alamat, style: const TextStyle(fontSize: 11, color: AppColors.text3)),
        ],
      ),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          IconButton(
            icon: const Icon(Icons.edit, size: 18),
            onPressed: () => _showAddForm(s),
          ),
          IconButton(
            icon: const Icon(Icons.delete_outline, size: 18, color: AppColors.danger),
            onPressed: () => _deleteSupplier(s),
          ),
        ],
      ),
    );
  }

  Widget _buildEmpty() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Text('🏢', style: TextStyle(fontSize: 60)),
          const SizedBox(height: 12),
          const Text('Belum ada supplier', style: TextStyle(fontSize: 15, color: AppColors.text3)),
          const SizedBox(height: 8),
          ElevatedButton(onPressed: () => _showAddForm(), child: const Text('Tambah Supplier')),
        ],
      ),
    );
  }
}

// ==================== SUPPLIER FORM ====================
class _SupplierForm extends StatefulWidget {
  final Supplier? supplier;
  final Function(Supplier) onSave;
  const _SupplierForm({this.supplier, required this.onSave});

  @override
  State<_SupplierForm> createState() => _SupplierFormState();
}

class _SupplierFormState extends State<_SupplierForm> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _namaCtrl, _kontakCtrl, _teleponCtrl, _emailCtrl, _kotaCtrl, _alamatCtrl;
  String _status = 'aktif';

  @override
  void initState() {
    super.initState();
    final s = widget.supplier;
    _namaCtrl = TextEditingController(text: s?.nama ?? '');
    _kontakCtrl = TextEditingController(text: s?.kontak ?? '');
    _teleponCtrl = TextEditingController(text: s?.telepon ?? '');
    _emailCtrl = TextEditingController(text: s?.email ?? '');
    _kotaCtrl = TextEditingController(text: s?.kota ?? '');
    _alamatCtrl = TextEditingController(text: s?.alamat ?? '');
    _status = s?.status ?? 'aktif';
  }

  @override
  void dispose() {
    for (final c in [_namaCtrl, _kontakCtrl, _teleponCtrl, _emailCtrl, _kotaCtrl, _alamatCtrl]) {
      c.dispose();
    }
    super.dispose();
  }

  void _save() {
    if (!_formKey.currentState!.validate()) return;
    final s = Supplier(
      id: widget.supplier?.id,
      nama: _namaCtrl.text.trim(),
      kontak: _kontakCtrl.text.trim(),
      telepon: _teleponCtrl.text.trim(),
      email: _emailCtrl.text.trim(),
      kota: _kotaCtrl.text.trim(),
      alamat: _alamatCtrl.text.trim(),
      status: _status,
    );
    Navigator.pop(context);
    widget.onSave(s);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Center(child: Container(width: 36, height: 4, decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(2)))),
                const SizedBox(height: 20),
                Text(widget.supplier == null ? 'Tambah Supplier Baru' : 'Edit Supplier',
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                const SizedBox(height: 16),
                _buildTextField('Nama Supplier *', _namaCtrl),
                const SizedBox(height: 12),
                _buildTextField('Kontak (Person)', _kontakCtrl),
                const SizedBox(height: 12),
                _buildTextField('Telepon', _teleponCtrl, isNumber: true),
                const SizedBox(height: 12),
                _buildTextField('Email', _emailCtrl),
                const SizedBox(height: 12),
                _buildTextField('Kota', _kotaCtrl),
                const SizedBox(height: 12),
                _buildTextField('Alamat', _alamatCtrl, maxLines: 2),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  value: _status,
                  items: const [
                    DropdownMenuItem(value: 'aktif', child: Text('Aktif')),
                    DropdownMenuItem(value: 'nonaktif', child: Text('Nonaktif')),
                  ],
                  onChanged: (v) => setState(() => _status = v!),
                  decoration: const InputDecoration(labelText: 'Status'),
                ),
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(onPressed: _save, child: Text(widget.supplier == null ? 'Simpan Supplier' : 'Update Supplier')),
                ),
                const SizedBox(height: 8),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(String label, TextEditingController ctrl, {bool isNumber = false, int maxLines = 1}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
        const SizedBox(height: 6),
        TextFormField(
          controller: ctrl,
          keyboardType: isNumber ? TextInputType.phone : TextInputType.text,
          maxLines: maxLines,
          validator: (v) => (v == null || v.isEmpty) && label.contains('*') ? 'Wajib diisi' : null,
          decoration: InputDecoration(hintText: 'Masukkan $label'),
        ),
      ],
    );
  }
}
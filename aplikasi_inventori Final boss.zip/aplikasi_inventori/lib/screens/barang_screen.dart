// lib/screens/barang_screen.dart
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/barang_model.dart';
import '../theme/app_theme.dart';

class BarangScreen extends StatefulWidget {
  const BarangScreen({super.key});

  @override
  State<BarangScreen> createState() => _BarangScreenState();
}

class _BarangScreenState extends State<BarangScreen> {
  final _supabase = Supabase.instance.client;
  List<Barang> _barangList = [];
  List<Barang> _filtered = [];
  bool _isLoading = true;
  String _selectedJenis = 'Semua';
  final _searchCtrl = TextEditingController();

  static const List<String> _jenisList = ['Semua', 'Elektronik', 'Alat Tulis', 'Furnitur', 'Konsumsi', 'Lainnya'];

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    try {
      final response = await _supabase.from('barang').select('*');
      final List<Barang> data = (response as List)
          .map((json) => Barang.fromMap(json))
          .toList();
      if (mounted) {
        setState(() {
          _barangList = data;
          _applyFilter();
          _isLoading = false;
        });
      }
    } catch (e) {
      print('Error load barang: $e');
      if (mounted) {
        setState(() => _isLoading = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal memuat data: $e'), backgroundColor: AppColors.danger),
        );
      }
    }
  }

  void _applyFilter() {
    final q = _searchCtrl.text.toLowerCase();
    _filtered = _barangList.where((b) {
      final matchJenis = _selectedJenis == 'Semua' || b.jenis == _selectedJenis;
      final matchSearch = q.isEmpty || b.nama.toLowerCase().contains(q) || b.jenis.toLowerCase().contains(q);
      return matchJenis && matchSearch;
    }).toList();
  }

  void _showAddForm([Barang? existing]) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (_) => _BarangForm(
        barang: existing,
        onSave: (b) async {
          try {
            if (existing == null) {
              // Insert baru
              final Map<String, dynamic> data = b.toMap();
              // Hapus id karena biar auto generate di Supabase (jika id bigserial)
              data.remove('id');
              await _supabase.from('barang').insert(data);
            } else {
              // Update
              await _supabase.from('barang').update(b.toMap()).eq('id', b.id!);
            }
            // Refresh UI
            await _loadData();
            if (mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(existing == null ? 'Barang berhasil ditambahkan' : 'Barang berhasil diperbarui'),
                  backgroundColor: AppColors.primary,
                  behavior: SnackBarBehavior.floating,
                ),
              );
            }
          } catch (e) {
            print('Error save barang: $e');
            if (mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Gagal menyimpan: $e'), backgroundColor: AppColors.danger),
              );
            }
          }
        },
      ),
    );
  }

  void _deleteBarang(Barang b) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Hapus Barang'),
        content: Text('Yakin ingin menghapus ${b.nama}?\nSemua data transaksi terkait akan ikut terhapus.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.danger),
            child: const Text('Hapus'),
          ),
        ],
      ),
    );
    if (confirm == true) {
      try {
        await _supabase.from('barang').delete().eq('id', b.id!);
        await _loadData();
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('${b.nama} berhasil dihapus'), backgroundColor: AppColors.danger),
          );
        }
      } catch (e) {
        print('Error delete barang: $e');
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Gagal menghapus: $e'), backgroundColor: AppColors.danger),
          );
        }
      }
    }
  }

  // Warna untuk badge jenis
  Color _jenisColor(String jenis) {
    const map = {
      'Elektronik': Color(0xFFEEF2FF),
      'Alat Tulis': AppColors.primaryLighter,
      'Furnitur': AppColors.accentLight,
      'Konsumsi': AppColors.dangerLight,
    };
    return map[jenis] ?? AppColors.bg;
  }

  Color _jenisTextColor(String jenis) {
    const map = {
      'Elektronik': Color(0xFF4F46E5),
      'Alat Tulis': AppColors.primary,
      'Furnitur': Color(0xFFB45309),
      'Konsumsi': AppColors.danger,
    };
    return map[jenis] ?? AppColors.text2;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(
        title: const Text('Daftar Barang'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded, color: Colors.white),
            onPressed: _loadData,
            tooltip: 'Refresh',
          ),
          Padding(
            padding: const EdgeInsets.only(right: 8),
            child: TextButton.icon(
              onPressed: () => _showAddForm(),
              icon: const Icon(Icons.add_rounded, color: Colors.white, size: 18),
              label: const Text('Tambah', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
            ),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _loadData,
        color: AppColors.primary,
        child: Column(
          children: [
            // Search bar
            Container(
              margin: const EdgeInsets.fromLTRB(16, 12, 16, 8),
              padding: const EdgeInsets.symmetric(horizontal: 14),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColors.border),
              ),
              child: Row(
                children: [
                  const Icon(Icons.search_rounded, color: AppColors.text3, size: 20),
                  const SizedBox(width: 8),
                  Expanded(
                    child: TextField(
                      controller: _searchCtrl,
                      onChanged: (_) => setState(() => _applyFilter()),
                      decoration: const InputDecoration(
                        hintText: 'Cari nama barang...',
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.symmetric(vertical: 12),
                      ),
                      style: const TextStyle(fontSize: 14),
                    ),
                  ),
                ],
              ),
            ),
            // Filter chips
            SizedBox(
              height: 38,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                itemCount: _jenisList.length,
                separatorBuilder: (_, __) => const SizedBox(width: 8),
                itemBuilder: (_, i) {
                  final j = _jenisList[i];
                  final selected = _selectedJenis == j;
                  return GestureDetector(
                    onTap: () => setState(() { _selectedJenis = j; _applyFilter(); }),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                      decoration: BoxDecoration(
                        color: selected ? AppColors.primary : AppColors.surface,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: selected ? AppColors.primary : AppColors.border),
                      ),
                      child: Text(j, style: TextStyle(
                        fontSize: 12, fontWeight: FontWeight.w600,
                        color: selected ? Colors.white : AppColors.text2,
                      )),
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 4),
            // Info bar
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              child: Row(
                children: [
                  Text('${_filtered.length} barang', style: const TextStyle(fontSize: 12, color: AppColors.text3, fontWeight: FontWeight.w500)),
                  const Spacer(),
                  if (_filtered.any((b) => b.isStokRendah))
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(color: AppColors.warningLight, borderRadius: BorderRadius.circular(10)),
                      child: Text(
                        '${_filtered.where((b) => b.isStokRendah).length} stok rendah',
                        style: const TextStyle(fontSize: 11, color: AppColors.warning, fontWeight: FontWeight.w600),
                      ),
                    ),
                ],
              ),
            ),
            // Grid responsif
            Expanded(
              child: _isLoading
                  ? const Center(child: CircularProgressIndicator(color: AppColors.primary))
                  : _filtered.isEmpty
                      ? _buildEmpty()
                      : GridView.builder(
                          padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
                          gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                            maxCrossAxisExtent: 180,
                            crossAxisSpacing: 12,
                            mainAxisSpacing: 12,
                            childAspectRatio: 0.75,
                          ),
                          itemCount: _filtered.length,
                          itemBuilder: (_, i) => _buildCard(_filtered[i]),
                        ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCard(Barang b) {
    final jColor = _jenisColor(b.jenis);
    final jTextColor = _jenisTextColor(b.jenis);
    return GestureDetector(
      onTap: () => _showDetailDialog(b),
      child: Container(
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: b.isStokRendah ? AppColors.danger.withOpacity(0.3) : AppColors.border,
            width: 1.0,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.04),
              blurRadius: 6,
              offset: const Offset(0, 1),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Gambar / Emoji
            Container(
              height: 100,
              width: double.infinity,
              decoration: BoxDecoration(color: jColor, borderRadius: const BorderRadius.vertical(top: Radius.circular(16))),
              child: b.fotoPath != null && File(b.fotoPath!).existsSync()
                  ? ClipRRect(
                      borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
                      child: Image.file(File(b.fotoPath!), fit: BoxFit.cover, width: double.infinity),
                    )
                  : Center(child: Text(b.ikon, style: const TextStyle(fontSize: 44))),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(10, 8, 10, 8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(b.nama, maxLines: 1, overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.text1)),
                  const SizedBox(height: 3),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(color: jColor, borderRadius: BorderRadius.circular(6)),
                    child: Text(b.jenis, style: TextStyle(fontSize: 10, fontWeight: FontWeight.w600, color: jTextColor)),
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('${b.stok}', style: TextStyle(
                            fontSize: 20, fontWeight: FontWeight.w800,
                            color: b.isStokKosong ? AppColors.danger : (b.isStokRendah ? AppColors.warning : AppColors.primary),
                          )),
                          Text(b.satuan, style: const TextStyle(fontSize: 10, color: AppColors.text3)),
                        ],
                      ),
                      const Spacer(),
                      if (b.isStokKosong)
                        _buildBadge('HABIS', AppColors.danger, AppColors.dangerLight)
                      else if (b.isStokRendah)
                        _buildBadge('RENDAH', AppColors.warning, AppColors.warningLight),
                    ],
                  ),
                  const SizedBox(height: 6),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(3),
                    child: LinearProgressIndicator(
                      value: b.stokPercentage,
                      minHeight: 4,
                      backgroundColor: AppColors.border,
                      color: b.isStokKosong ? AppColors.danger : (b.isStokRendah ? AppColors.warning : AppColors.primary),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBadge(String label, Color color, Color bg) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(6)),
      child: Text(label, style: TextStyle(fontSize: 9, fontWeight: FontWeight.w800, color: color)),
    );
  }

  void _showDetailDialog(Barang b) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(b.ikon, style: const TextStyle(fontSize: 50)),
            const SizedBox(height: 8),
            Text(b.nama, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700, color: AppColors.text1), textAlign: TextAlign.center),
            const SizedBox(height: 4),
            Text(b.jenis, style: const TextStyle(fontSize: 12, color: AppColors.text3)),
            const SizedBox(height: 16),
            _detailRow('Stok', '${b.stok} ${b.satuan}'),
            _detailRow('Stok Minimum', '${b.stokMinimum} ${b.satuan}'),
            if (b.supplierNama != null) _detailRow('Supplier', b.supplierNama!),
            if (b.keterangan.isNotEmpty) _detailRow('Keterangan', b.keterangan),
          ],
        ),
        actions: [
          TextButton(onPressed: () { Navigator.pop(context); _deleteBarang(b); }, child: const Text('Hapus', style: TextStyle(color: AppColors.danger))),
          ElevatedButton(onPressed: () { Navigator.pop(context); _showAddForm(b); }, child: const Text('Edit')),
        ],
      ),
    );
  }

  Widget _detailRow(String k, String v) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Text(k, style: const TextStyle(fontSize: 12, color: AppColors.text3)),
          const Spacer(),
          Text(v, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.text1)),
        ],
      ),
    );
  }

  Widget _buildEmpty() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Text('📦', style: TextStyle(fontSize: 60)),
          const SizedBox(height: 12),
          const Text('Belum ada barang', style: TextStyle(fontSize: 15, color: AppColors.text3)),
          const SizedBox(height: 8),
          ElevatedButton(onPressed: () => _showAddForm(), child: const Text('Tambah Barang')),
        ],
      ),
    );
  }
}

// ==================== BARANG FORM (dengan Supabase saja) ====================
class _BarangForm extends StatefulWidget {
  final Barang? barang;
  final Function(Barang) onSave;
  const _BarangForm({this.barang, required this.onSave});

  @override
  State<_BarangForm> createState() => _BarangFormState();
}

class _BarangFormState extends State<_BarangForm> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _namaCtrl, _stokCtrl, _stokMinCtrl, _ketCtrl;
  String _jenis = 'Elektronik';
  String _satuan = 'pcs';
  String _ikon = '📦';
  String? _fotoPath;
  final _picker = ImagePicker();

  static const _ikonList = ['📦', '💻', '🖱️', '⌨️', '🖨️', '📱', '📷', '📄', '✏️', '📓', '🗂️', '🪑', '🪵', '🗒️', '💧', '🍵', '🔧', '📡', '🖥️', '📺', '🔌', '💡', '🧴', '🍱'];
  static const _jenisList = ['Elektronik', 'Alat Tulis', 'Furnitur', 'Konsumsi', 'Lainnya'];
  static const _satuanList = ['pcs', 'unit', 'rim', 'lusin', 'dus', 'kotak', 'kg', 'liter', 'meter', 'set', 'buah'];

  @override
  void initState() {
    super.initState();
    final b = widget.barang;
    _namaCtrl = TextEditingController(text: b?.nama ?? '');
    _stokCtrl = TextEditingController(text: b?.stok.toString() ?? '0');
    _stokMinCtrl = TextEditingController(text: b?.stokMinimum.toString() ?? '5');
    _ketCtrl = TextEditingController(text: b?.keterangan ?? '');
    _jenis = b?.jenis ?? 'Elektronik';
    _satuan = b?.satuan ?? 'pcs';
    _ikon = b?.ikon ?? '📦';
    _fotoPath = b?.fotoPath;
  }

  @override
  void dispose() {
    for (final c in [_namaCtrl, _stokCtrl, _stokMinCtrl, _ketCtrl]) { c.dispose(); }
    super.dispose();
  }

  Future<void> _pickImage() async {
    final source = await showModalBottomSheet<ImageSource>(
      context: context,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(leading: const Icon(Icons.camera_alt_rounded, color: AppColors.primary), title: const Text('Kamera'), onTap: () => Navigator.pop(context, ImageSource.camera)),
            ListTile(leading: const Icon(Icons.photo_library_rounded, color: AppColors.primary), title: const Text('Galeri'), onTap: () => Navigator.pop(context, ImageSource.gallery)),
          ],
        ),
      ),
    );
    if (source == null) return;
    final img = await _picker.pickImage(source: source, maxWidth: 800, imageQuality: 80);
    if (img != null && mounted) setState(() => _fotoPath = img.path);
  }

  void _save() {
    if (!_formKey.currentState!.validate()) return;
    final b = Barang(
      id: widget.barang?.id,
      nama: _namaCtrl.text.trim(),
      jenis: _jenis,
      satuan: _satuan,
      stok: int.tryParse(_stokCtrl.text) ?? 0,
      stokMinimum: int.tryParse(_stokMinCtrl.text) ?? 5,
      fotoPath: _fotoPath,
      ikon: _ikon,
      keterangan: _ketCtrl.text.trim(),
    );
    Navigator.pop(context);
    widget.onSave(b);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Center(child: Container(width: 36, height: 4, decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(2)))),
                const SizedBox(height: 20),
                Text(widget.barang == null ? 'Tambah Barang Baru' : 'Edit Barang',
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: AppColors.text1)),
                const SizedBox(height: 16),
                // Foto picker
                const Text('Foto Barang', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.text2)),
                const SizedBox(height: 8),
                GestureDetector(
                  onTap: _pickImage,
                  child: Container(
                    height: 120, width: double.infinity,
                    decoration: BoxDecoration(
                      color: AppColors.bg, borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: AppColors.border, width: 1.5),
                    ),
                    child: _fotoPath != null && File(_fotoPath!).existsSync()
                        ? ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.file(File(_fotoPath!), fit: BoxFit.cover))
                        : Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Icon(Icons.camera_alt_outlined, color: AppColors.text3, size: 28),
                              const SizedBox(height: 6),
                              const Text('Ketuk untuk memilih foto', style: TextStyle(fontSize: 12, color: AppColors.text3)),
                            ],
                          ),
                  ),
                ),
                const SizedBox(height: 14),
                // Ikon picker
                const Text('Pilih Ikon Emoji', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.text2)),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 6, runSpacing: 6,
                  children: _ikonList.map((e) {
                    final sel = _ikon == e;
                    return GestureDetector(
                      onTap: () => setState(() => _ikon = e),
                      child: Container(
                        width: 42, height: 42,
                        decoration: BoxDecoration(
                          color: sel ? AppColors.primaryLighter : AppColors.bg,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: sel ? AppColors.primary : AppColors.border, width: sel ? 2 : 1),
                        ),
                        child: Center(child: Text(e, style: const TextStyle(fontSize: 20))),
                      ),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 14),
                // Nama
                const Text('Nama Barang *', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.text2)),
                const SizedBox(height: 6),
                TextFormField(
                  controller: _namaCtrl,
                  validator: (v) => (v == null || v.isEmpty) ? 'Nama wajib diisi' : null,
                  decoration: const InputDecoration(hintText: 'Masukkan nama barang...'),
                ),
                const SizedBox(height: 12),
                // Jenis + Satuan
                Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('Jenis', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.text2)),
                          const SizedBox(height: 6),
                          DropdownButtonFormField<String>(
                            initialValue: _jenis,
                            items: _jenisList.map((j) => DropdownMenuItem(value: j, child: Text(j, style: const TextStyle(fontSize: 13)))).toList(),
                            onChanged: (v) => setState(() => _jenis = v!),
                            decoration: const InputDecoration(contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 12)),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('Satuan', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.text2)),
                          const SizedBox(height: 6),
                          DropdownButtonFormField<String>(
                            initialValue: _satuan,
                            items: _satuanList.map((s) => DropdownMenuItem(value: s, child: Text(s, style: const TextStyle(fontSize: 13)))).toList(),
                            onChanged: (v) => setState(() => _satuan = v!),
                            decoration: const InputDecoration(contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 12)),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(child: _buildNumField('Stok Awal', _stokCtrl)),
                    const SizedBox(width: 12),
                    Expanded(child: _buildNumField('Stok Minimum', _stokMinCtrl)),
                  ],
                ),
                const SizedBox(height: 12),
                const Text('Keterangan', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.text2)),
                const SizedBox(height: 6),
                TextFormField(controller: _ketCtrl, maxLines: 2, decoration: const InputDecoration(hintText: 'Deskripsi singkat barang...')),
                const SizedBox(height: 20),
                SizedBox(width: double.infinity, child: ElevatedButton(onPressed: _save, child: Text(widget.barang == null ? 'Simpan Barang' : 'Update Barang'))),
                const SizedBox(height: 8),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildNumField(String label, TextEditingController ctrl) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.text2)),
        const SizedBox(height: 6),
        TextFormField(
          controller: ctrl,
          keyboardType: TextInputType.number,
          validator: (v) => (v == null || v.isEmpty) ? 'Wajib diisi' : null,
          decoration: const InputDecoration(),
        ),
      ],
    );
  }
}
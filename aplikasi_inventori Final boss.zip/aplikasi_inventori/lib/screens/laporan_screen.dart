// lib/screens/laporan_screen.dart
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:excel/excel.dart' hide Border;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'dart:io';
import '../models/barang_model.dart';
import '../models/transaksi_model.dart';
import '../theme/app_theme.dart';

class LaporanScreen extends StatefulWidget {
  const LaporanScreen({super.key});

  @override
  State<LaporanScreen> createState() => _LaporanScreenState();
}

class _LaporanScreenState extends State<LaporanScreen> {
  final _supabase = Supabase.instance.client;

  // Data statistik dan laporan
  Map<String, int> _stats = {};
  List<Map<String, dynamic>> _laporan = [];
  bool _isLoading = true;
  bool _isExporting = false;

  // Rentang tanggal
  DateTime _startDate = DateTime.now().subtract(const Duration(days: 30));
  DateTime _endDate = DateTime.now();

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    try {
      // 1. Ambil semua data barang (untuk daftar barang & stok terakhir)
      final barangRes = await _supabase.from('barang').select();
      final List<Barang> barangList = (barangRes as List)
          .map((json) => Barang.fromMap(json))
          .toList();

      // 2. Ambil transaksi dalam periode yang dipilih
      final startIso = _startDate.toIso8601String();
      final endIso = _endDate.add(const Duration(days: 1)).toIso8601String();
      final transRes = await _supabase
          .from('transaksi')
          .select()
          .gte('created_at', startIso)
          .lt('created_at', endIso);
      final List<Transaksi> transList = (transRes as List)
          .map((json) => Transaksi.fromMap(json))
          .toList();

      // 3. Hitung statistik ringkasan
      int totalStok = 0;
      int totalMasuk = 0;
      int totalKeluar = 0;
      int jenisBarang = barangList.length;
      int stokRendah = 0;

      for (var b in barangList) {
        totalStok += b.stok;
        if (b.isStokRendah) stokRendah++;
      }
      for (var t in transList) {
        if (t.tipe == TipeTransaksi.masuk) totalMasuk += t.jumlah;
        else totalKeluar += t.jumlah;
      }

      _stats = {
        'total_stok': totalStok,
        'total_masuk': totalMasuk,
        'total_keluar': totalKeluar,
        'jenis_barang': jenisBarang,
        'stok_rendah': stokRendah,
      };

      // 4. Hitung laporan per barang (agregasi masuk & keluar selama periode)
      final Map<int, Map<String, dynamic>> reportMap = {};
      for (var b in barangList) {
        reportMap[b.id!] = {
          'id': b.id,
          'nama': b.nama,
          'jenis': b.jenis,
          'satuan': b.satuan,
          'ikon': b.ikon,
          'stok': b.stok,
          'total_masuk': 0,
          'total_keluar': 0,
        };
      }
      for (var t in transList) {
        var item = reportMap[t.barangId];
        if (item != null) {
          if (t.tipe == TipeTransaksi.masuk) item['total_masuk'] += t.jumlah;
          else item['total_keluar'] += t.jumlah;
        }
      }
      _laporan = reportMap.values.toList();

      // 5. Urutkan berdasarkan nama barang
      _laporan.sort((a, b) => (a['nama'] as String).compareTo(b['nama'] as String));

      if (mounted) setState(() => _isLoading = false);
    } catch (e) {
      print('Error load laporan: $e');
      if (mounted) {
        setState(() => _isLoading = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal memuat laporan: $e'), backgroundColor: AppColors.danger),
        );
      }
    }
  }

  Future<void> _pickDateRange() async {
    final picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2020),
      lastDate: DateTime.now(),
      initialDateRange: DateTimeRange(start: _startDate, end: _endDate),
      builder: (ctx, child) => Theme(
        data: Theme.of(ctx).copyWith(colorScheme: const ColorScheme.light(primary: AppColors.primary)),
        child: child!,
      ),
    );
    if (picked != null) {
      setState(() {
        _startDate = picked.start;
        _endDate = picked.end;
      });
      _loadData();
    }
  }

  // -------------------- EXPORT (tidak banyak berubah) --------------------
  Future<void> _exportPDF() async {
    setState(() => _isExporting = true);
    try {
      final pdf = pw.Document();
      pdf.addPage(pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(32),
        build: (ctx) => [
          pw.Header(
            level: 0,
            child: pw.Row(
              mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
              children: [
                pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: [
                    pw.Text('LAPORAN INVENTARIS BARANG',
                        style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold)),
                    pw.Text('PT / Instansi Anda',
                        style: const pw.TextStyle(fontSize: 11, color: PdfColors.grey600)),
                  ],
                ),
                pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.end,
                  children: [
                    pw.Text(
                        'Periode: ${DateFormat('dd MMM yyyy').format(_startDate)} - ${DateFormat('dd MMM yyyy').format(_endDate)}',
                        style: const pw.TextStyle(fontSize: 10, color: PdfColors.grey700)),
                    pw.Text('Dicetak: ${DateFormat('dd MMM yyyy HH:mm').format(DateTime.now())}',
                        style: const pw.TextStyle(fontSize: 10, color: PdfColors.grey700)),
                  ],
                ),
              ],
            ),
          ),
          pw.SizedBox(height: 16),
          pw.Container(
            padding: const pw.EdgeInsets.all(12),
            decoration: pw.BoxDecoration(
                color: const PdfColor(0.106, 0.369, 0.231), borderRadius: pw.BorderRadius.circular(8)),
            child: pw.Row(
              mainAxisAlignment: pw.MainAxisAlignment.spaceAround,
              children: [
                _pdfStatBox('Total Stok', '${_stats['total_stok'] ?? 0}'),
                _pdfStatBox('Total Masuk', '${_stats['total_masuk'] ?? 0}'),
                _pdfStatBox('Total Keluar', '${_stats['total_keluar'] ?? 0}'),
                _pdfStatBox('Jenis Barang', '${_stats['jenis_barang'] ?? 0}'),
              ],
            ),
          ),
          pw.SizedBox(height: 16),
          pw.Text('Detail Laporan Per Barang',
              style: pw.TextStyle(fontSize: 13, fontWeight: pw.FontWeight.bold)),
          pw.SizedBox(height: 8),
          pw.Table(
            border: pw.TableBorder.all(color: PdfColors.grey300, width: 0.5),
            columnWidths: {
              0: const pw.FlexColumnWidth(3),
              1: const pw.FlexColumnWidth(2),
              2: const pw.FlexColumnWidth(1.5),
              3: const pw.FlexColumnWidth(1.5),
              4: const pw.FlexColumnWidth(1.5),
            },
            children: [
              pw.TableRow(
                decoration: const pw.BoxDecoration(color: PdfColor(0.106, 0.369, 0.231)),
                children: ['Nama Barang', 'Jenis', 'Masuk', 'Keluar', 'Sisa Stok']
                    .map((h) => pw.Padding(
                          padding: const pw.EdgeInsets.symmetric(horizontal: 8, vertical: 7),
                          child: pw.Text(h,
                              style: pw.TextStyle(
                                  color: PdfColors.white, fontSize: 9, fontWeight: pw.FontWeight.bold)),
                        ))
                    .toList(),
              ),
              ..._laporan.asMap().entries.map((e) {
                final b = e.value;
                final isEven = e.key % 2 == 0;
                return pw.TableRow(
                  decoration: pw.BoxDecoration(
                      color: isEven ? PdfColors.white : const PdfColor(0.96, 0.98, 0.96)),
                  children: [
                    pw.Padding(
                        padding: const pw.EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                        child: pw.Text('${b['ikon']} ${b['nama']}', style: const pw.TextStyle(fontSize: 9))),
                    pw.Padding(
                        padding: const pw.EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                        child: pw.Text('${b['jenis']}', style: const pw.TextStyle(fontSize: 9))),
                    pw.Padding(
                        padding: const pw.EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                        child: pw.Text('${b['total_masuk']}', style: const pw.TextStyle(fontSize: 9))),
                    pw.Padding(
                        padding: const pw.EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                        child: pw.Text('${b['total_keluar']}', style: const pw.TextStyle(fontSize: 9))),
                    pw.Padding(
                        padding: const pw.EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                        child: pw.Text('${b['stok']} ${b['satuan']}',
                            style: pw.TextStyle(fontSize: 9, fontWeight: pw.FontWeight.bold))),
                  ],
                );
              }),
            ],
          ),
          pw.SizedBox(height: 20),
          pw.Divider(),
          pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            children: [
              pw.Text('Dibuat oleh sistem inventaris otomatis',
                  style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey600)),
              pw.Column(
                children: [
                  pw.SizedBox(height: 40),
                  pw.Text('(____________________)', style: const pw.TextStyle(fontSize: 9)),
                  pw.Text('Admin / Penanggung Jawab',
                      style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey600)),
                ],
              ),
            ],
          ),
        ],
      ));
      await Printing.layoutPdf(onLayout: (fmt) async => pdf.save());
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e'), backgroundColor: AppColors.danger, behavior: SnackBarBehavior.floating),
        );
      }
    } finally {
      if (mounted) setState(() => _isExporting = false);
    }
  }

  pw.Widget _pdfStatBox(String label, String value) {
    return pw.Column(
      children: [
        pw.Text(value, style: pw.TextStyle(color: PdfColors.white, fontSize: 18, fontWeight: pw.FontWeight.bold)),
        pw.Text(label, style: const pw.TextStyle(color: PdfColors.white, fontSize: 9)),
      ],
    );
  }

  Future<void> _exportExcel() async {
    setState(() => _isExporting = true);
    try {
      final excel = Excel.createExcel();
      final sheet = excel['Laporan Inventaris'];
      excel.delete('Sheet1');

      // Title
      sheet.cell(CellIndex.indexByString('A1')).value = TextCellValue('LAPORAN INVENTARIS BARANG');
      sheet.cell(CellIndex.indexByString('A2')).value = TextCellValue(
          'Periode: ${DateFormat('dd MMM yyyy').format(_startDate)} - ${DateFormat('dd MMM yyyy').format(_endDate)}');
      sheet.cell(CellIndex.indexByString('A3')).value =
          TextCellValue('Dicetak: ${DateFormat('dd MMM yyyy HH:mm').format(DateTime.now())}');

      // Summary
      sheet.cell(CellIndex.indexByString('A5')).value = TextCellValue('RINGKASAN');
      sheet.cell(CellIndex.indexByString('A6')).value = TextCellValue('Total Stok');
      sheet.cell(CellIndex.indexByString('B6')).value = IntCellValue(_stats['total_stok'] ?? 0);
      sheet.cell(CellIndex.indexByString('C6')).value = TextCellValue('Total Masuk');
      sheet.cell(CellIndex.indexByString('D6')).value = IntCellValue(_stats['total_masuk'] ?? 0);
      sheet.cell(CellIndex.indexByString('E6')).value = TextCellValue('Total Keluar');
      sheet.cell(CellIndex.indexByString('F6')).value = IntCellValue(_stats['total_keluar'] ?? 0);

      // Headers
      final headers = ['No', 'Nama Barang', 'Jenis', 'Satuan', 'Total Masuk', 'Total Keluar', 'Sisa Stok', 'Status'];
      for (int i = 0; i < headers.length; i++) {
        sheet.cell(CellIndex.indexByColumnRow(columnIndex: i, rowIndex: 8)).value = TextCellValue(headers[i]);
      }

      // Data
      for (int i = 0; i < _laporan.length; i++) {
        final b = _laporan[i];
        final row = 9 + i;
        sheet.cell(CellIndex.indexByColumnRow(columnIndex: 0, rowIndex: row)).value = IntCellValue(i + 1);
        sheet.cell(CellIndex.indexByColumnRow(columnIndex: 1, rowIndex: row)).value = TextCellValue(b['nama']);
        sheet.cell(CellIndex.indexByColumnRow(columnIndex: 2, rowIndex: row)).value = TextCellValue(b['jenis']);
        sheet.cell(CellIndex.indexByColumnRow(columnIndex: 3, rowIndex: row)).value = TextCellValue(b['satuan']);
        sheet.cell(CellIndex.indexByColumnRow(columnIndex: 4, rowIndex: row)).value = IntCellValue(b['total_masuk']);
        sheet.cell(CellIndex.indexByColumnRow(columnIndex: 5, rowIndex: row)).value = IntCellValue(b['total_keluar']);
        sheet.cell(CellIndex.indexByColumnRow(columnIndex: 6, rowIndex: row)).value = IntCellValue(b['stok']);
        final stok = b['stok'] as int;
        sheet.cell(CellIndex.indexByColumnRow(columnIndex: 7, rowIndex: row)).value =
            TextCellValue(stok == 0 ? 'HABIS' : (stok <= 5 ? 'RENDAH' : 'NORMAL'));
      }

      final dir = await getApplicationDocumentsDirectory();
      final fileName = 'Laporan_Inventaris_${DateFormat('yyyyMMdd_HHmm').format(DateTime.now())}.xlsx';
      final file = File('${dir.path}/$fileName');
      file.writeAsBytesSync(excel.save()!);
      await Share.shareXFiles([XFile(file.path)], text: 'Laporan Inventaris Barang - $fileName');
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error export Excel: $e'), backgroundColor: AppColors.danger, behavior: SnackBarBehavior.floating),
        );
      }
    } finally {
      if (mounted) setState(() => _isExporting = false);
    }
  }

  // -------------------- UI (hampir sama, hanya disesuaikan periode & refresh) --------------------
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(
        title: const Text('Laporan Inventaris'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded),
            onPressed: _loadData,
            tooltip: 'Refresh',
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _loadData,
        color: AppColors.primary,
        child: _isLoading
            ? const Center(child: CircularProgressIndicator(color: AppColors.primary))
            : CustomScrollView(
                slivers: [
                  SliverToBoxAdapter(child: _buildPeriodeSelector()),
                  SliverToBoxAdapter(child: _buildSummaryCards()),
                  SliverToBoxAdapter(child: _buildExportButtons()),
                  SliverToBoxAdapter(child: _buildTableHeader()),
                  SliverToBoxAdapter(child: _buildTable()),
                  const SliverToBoxAdapter(child: SizedBox(height: 24)),
                ],
              ),
      ),
    );
  }

  Widget _buildPeriodeSelector() {
    return GestureDetector(
      onTap: _pickDateRange,
      child: Container(
        margin: const EdgeInsets.all(16),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppColors.border),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 6)],
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(color: AppColors.primaryLighter, borderRadius: BorderRadius.circular(8)),
              child: const Icon(Icons.calendar_month_rounded, color: AppColors.primary, size: 18),
            ),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Periode Laporan', style: TextStyle(fontSize: 11, color: AppColors.text3, fontWeight: FontWeight.w500)),
                Text('${DateFormat('dd MMM yyyy').format(_startDate)} — ${DateFormat('dd MMM yyyy').format(_endDate)}',
                    style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.text1)),
              ],
            ),
            const Spacer(),
            const Icon(Icons.chevron_right_rounded, color: AppColors.text3),
          ],
        ),
      ),
    );
  }

  Widget _buildSummaryCards() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(child: _buildSumCard('Total Stok', '${_stats['total_stok'] ?? 0}', Icons.inventory_2_rounded, AppColors.primary, AppColors.primaryLighter)),
              const SizedBox(width: 10),
              Expanded(child: _buildSumCard('Barang Masuk', '${_stats['total_masuk'] ?? 0}', Icons.arrow_downward_rounded, AppColors.success, AppColors.successLight)),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(child: _buildSumCard('Barang Keluar', '${_stats['total_keluar'] ?? 0}', Icons.arrow_upward_rounded, AppColors.danger, AppColors.dangerLight)),
              const SizedBox(width: 10),
              Expanded(child: _buildSumCard('Jenis Barang', '${_stats['jenis_barang'] ?? 0}', Icons.category_rounded, AppColors.info, AppColors.infoLight)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSumCard(String label, String value, IconData icon, Color color, Color bg) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border, width: 0.5),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 6)],
      ),
      child: Row(
        children: [
          Container(
            width: 40, height: 40,
            decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(10)),
            child: Icon(icon, color: color, size: 18),
          ),
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(value, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: color)),
              Text(label, style: const TextStyle(fontSize: 11, color: AppColors.text3)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildExportButtons() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 4),
      child: _isExporting
          ? const Center(child: Padding(padding: EdgeInsets.all(16), child: CircularProgressIndicator(color: AppColors.primary)))
          : Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _exportExcel,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF217346),
                      padding: const EdgeInsets.symmetric(vertical: 13),
                    ),
                    icon: const Icon(Icons.table_chart_rounded, size: 18),
                    label: const Text('Export Excel', style: TextStyle(fontWeight: FontWeight.w700)),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _exportPDF,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFDC143C),
                      padding: const EdgeInsets.symmetric(vertical: 13),
                    ),
                    icon: const Icon(Icons.picture_as_pdf_rounded, size: 18),
                    label: const Text('Export PDF', style: TextStyle(fontWeight: FontWeight.w700)),
                  ),
                ),
              ],
            ),
    );
  }

  Widget _buildTableHeader() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 10, 16, 0),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: const BoxDecoration(
        color: AppColors.primary,
        borderRadius: BorderRadius.vertical(top: Radius.circular(12)),
      ),
      child: const Row(
        children: [
          Expanded(flex: 3, child: Text('Nama Barang', style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w700))),
          Expanded(flex: 1, child: Text('Masuk', style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w700), textAlign: TextAlign.center)),
          Expanded(flex: 1, child: Text('Keluar', style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w700), textAlign: TextAlign.center)),
          Expanded(flex: 1, child: Text('Sisa', style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w700), textAlign: TextAlign.center)),
        ],
      ),
    );
  }

  Widget _buildTable() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 0),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: const BorderRadius.vertical(bottom: Radius.circular(12)),
        border: Border.all(color: AppColors.border, width: 0.5),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8, offset: const Offset(0, 2))],
      ),
      child: Column(
        children: _laporan.asMap().entries.map((e) {
          final i = e.key;
          final b = e.value;
          final isLast = i == _laporan.length - 1;
          final stok = b['stok'] as int;
          final Color stokColor = stok == 0 ? AppColors.danger : (stok <= 5 ? AppColors.warning : AppColors.primary);
          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
                child: Row(
                  children: [
                    Expanded(
                      flex: 3,
                      child: Row(
                        children: [
                          Text('${b['ikon']}', style: const TextStyle(fontSize: 14)),
                          const SizedBox(width: 6),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('${b['nama']}', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.text1), maxLines: 1, overflow: TextOverflow.ellipsis),
                                Text('${b['jenis']}', style: const TextStyle(fontSize: 10, color: AppColors.text3)),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Expanded(flex: 1, child: Text('${b['total_masuk']}', style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.success), textAlign: TextAlign.center)),
                    Expanded(flex: 1, child: Text('${b['total_keluar']}', style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.danger), textAlign: TextAlign.center)),
                    Expanded(flex: 1, child: Text('${b['stok']}', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: stokColor), textAlign: TextAlign.center)),
                  ],
                ),
              ),
              if (!isLast) const Divider(color: AppColors.divider, height: 1, indent: 12, endIndent: 12),
            ],
          );
        }).toList(),
      ),
    );
  }
}
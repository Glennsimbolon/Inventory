import 'package:flutter/material.dart';

class TransaksiForm extends StatefulWidget {
  final dynamic barang;
  final dynamic tipe;
  final Function(int jumlah, String ket, String noRef) onSave;

  const TransaksiForm({
    super.key,
    required this.barang,
    required this.tipe,
    required this.onSave,
  });

  @override
  State<TransaksiForm> createState() => _TransaksiFormState();
}

class _TransaksiFormState extends State<TransaksiForm> {
  final jumlahController = TextEditingController();
  final ketController = TextEditingController();
  final refController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 16,
        right: 16,
        top: 16,
        bottom: MediaQuery.of(context).viewInsets.bottom,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text("Transaksi Barang", style: TextStyle(fontWeight: FontWeight.bold)),
          SizedBox(height: 12),

          TextField(
            controller: jumlahController,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(labelText: "Jumlah"),
          ),

          TextField(
            controller: ketController,
            decoration: InputDecoration(labelText: "Keterangan"),
          ),

          TextField(
            controller: refController,
            decoration: InputDecoration(labelText: "No Referensi"),
          ),

          SizedBox(height: 16),

          ElevatedButton(
            onPressed: () {
              final jumlah = int.tryParse(jumlahController.text) ?? 0;
              widget.onSave(jumlah, ketController.text, refController.text);
              Navigator.pop(context);
            },
            child: Text("Simpan"),
          ),
        ],
      ),
    );
  }
}
import 'package:flutter/material.dart';


class RiwayatTransaksi extends StatefulWidget {
  final dynamic tipe;
  final ScrollController scrollController;

  const RiwayatTransaksi({
    super.key,
    required this.tipe,
    required this.scrollController,
  });

  @override
  State<RiwayatTransaksi> createState() => _RiwayatTransaksiState();
}

class _RiwayatTransaksiState extends State<RiwayatTransaksi> {
  @override
  Widget build(BuildContext context) {
    return ListView(
      controller: widget.scrollController,
      children: [
        ListTile(title: Text("Contoh Riwayat")),
      ],
    );
  }
}